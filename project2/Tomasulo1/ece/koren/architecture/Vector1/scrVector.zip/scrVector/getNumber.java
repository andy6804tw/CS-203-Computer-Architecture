/*
 * getNumber.java
 *
 * Created on February 1, 2005, 10:00 AM
 */

package vector;

/**
 *
 * @author Jun
 */

import javax.swing.JFrame;

public class getNumber {
    
    /** Creates a new instance of getNumber */
    public int getNumber(javax.swing.JComboBox boxSelection) {
        int temp = 0;
        Object tempOb = new Object();
        tempOb = boxSelection.getSelectedItem();
        temp = Integer.parseInt(tempOb.toString());
        return temp;
    }
    
}
