/*
 * calcuCycle.java
 *
 * Created on January 31, 2005, 2:58 PM
 */

package vector;

/**
 *
 * @author Jun
 */
public class calcuCycle {
    //private int interval;
    //private int instSelection;
    private int cycleLD, cycleADD, cycleMul, cycleDIV, ThADD, ThML, ThLS, ThDV;
    
    /** Creates a new instance of calcuCycle */
    public calcuCycle(int cycle_LD, int cycle_ADD, int cycle_Mul, int cycle_DIV, int ThOP_ADD, int ThOP_ML, int ThOP_LS, int ThOP_DV) {
        cycleLD = cycle_LD;
        cycleADD = cycle_ADD;
        cycleMul = cycle_Mul;
        cycleDIV = cycle_DIV;
        ThADD = ThOP_ADD;
        ThML = ThOP_ML;
        ThLS = ThOP_LS;
        ThDV = ThOP_DV;
    }
    public int getVal(int instSelection, int interval) {
        
        int returnVal = 0;
        //double interTemp = new double(VL/MVL); 
        //int interval = VL % MVL;
        switch (instSelection){
            case(0):
                returnVal = 0;
                break;
            case(1):
                returnVal = cycleLD + interval*ThLS -1;
                break;
            //case(2):
            //    returnVal = cycleLD + interval*ThLS -1;
            //    break;
            case(2):
                returnVal = cycleADD + interval*ThADD -1; 
                break;
            case(3):
                returnVal = cycleMul + interval*ThML -1; 
                break;
            case(4):
                returnVal = cycleDIV + interval*ThDV -1;
                break;
        }
        return returnVal;
    }

    public int getPreStart(int instSelection, int interval) {
        int PreStart = 0;
        switch (instSelection){
            case(0):
                PreStart = 0;
                break;
            case(1):
                PreStart = cycleLD;
                break;
            case(2):
                PreStart = cycleADD; 
                break;
            case(3):
                PreStart = cycleMul; 
                break;
            case(4):
                PreStart = cycleDIV; 
                break;
        }
        return PreStart;
    }
}
