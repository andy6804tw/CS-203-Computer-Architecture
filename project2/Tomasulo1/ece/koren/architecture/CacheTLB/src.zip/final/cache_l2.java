/**
 * @author Rakesh Kothari
 * @author Siddhartha Bunga
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
class cache_l2 extends cache
{
	
	cache_l2(int a)
	{
		super(a);
	}
	
	
}