package algo;
/*
 * Created on Nov 26, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Stages {

	private int issue;
	private int decode;
	private int execStart;
	private int execEnd;
	private int write;
	
	public int getStageCycle(int stage) {
		switch(stage) {
			case 1: 
				return issue;
			case 2: 
				return decode;
			case 3: 
				return execEnd;
			case 4: 
				return write;
		}
		return -1;
	}
	
	/**
	 * @return
	 */
	public int getDecode() {
		return decode;
	}

	/**
	 * @return
	 */
	public int getExecEnd() {
		return execEnd;
	}

	/**
	 * @return
	 */
	public int getExecStart() {
		return execStart;
	}

	/**
	 * @return
	 */
	public int getIssue() {
		return issue;
	}

	/**
	 * @return
	 */
	public int getWrite() {
		return write;
	}

	/**
	 * @param i
	 */
	public void setDecode(int i) {
		decode = i;
	}

	/**
	 * @param i
	 */
	public void setExecEnd(int i) {
		execEnd = i;
	}

	/**
	 * @param i
	 */
	public void setExecStart(int i) {
		execStart = i;
	}

	/**
	 * @param i
	 */
	public void setIssue(int i) {
		issue = i;
	}

	/**
	 * @param i
	 */
	public void setWrite(int i) {
		write = i;
	}

}
