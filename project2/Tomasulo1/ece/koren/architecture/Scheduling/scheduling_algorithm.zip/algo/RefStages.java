package algo;
/*
 * Created on Nov 26, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RefStages {
	private int issue[];
	private int i;
	private int decode[];
	private int d;
	private int execEnd[];
	private int e;
	private int write[];
	private int w; 
	private int structural[];
	private int s;
	
	private int maxNoDep = 20;
	
	public RefStages() {
		issue = new int[maxNoDep];
		decode = new int[maxNoDep];
		execEnd = new int[maxNoDep];
		write = new int[maxNoDep];
		structural = new int[maxNoDep];
		
		for(int j=0; j<maxNoDep; j++) {
			issue[j] = decode[j] = execEnd[j] = write[j] = structural[j] = -1;
		}
		i = d = e = w = s = -1;
	}

	public void addIssueDep(int nodeNo) {
		issue[++i] = nodeNo;
	}

	public void addDecodeDep(int nodeNo) {
		decode[++d] = nodeNo;
	}

	public void addExecDep(int nodeNo) {
		execEnd[++e] = nodeNo;
	}

	public void addWriteDep(int nodeNo) {
		write[++w] = nodeNo;
	}

	public void addStructuralDep(int nodeNo) {
		structural[++s] = nodeNo;
	}

	/**
	 * @return
	 */
	public int getDecode(int i) {
		return decode[i];
	}

	/**
	 * @return
	 */
	public int getExecEnd(int i) {
		return execEnd[i];
	}

	/**
	 * @return
	 */
	public int getIssue(int i) {
		return issue[i];
	}

	/**
	 * @return
	 */
	public int getWrite(int i) {
		return write[i];
	}

	public int getStructural(int i) {
		return structural[i];
	}

	/**
	 * @param is
	 */
	public void setDecode(int[] is) {
		decode = is;
	}

	/**
	 * @param is
	 */
	public void setExecEnd(int[] is) {
		execEnd = is;
	}

	/**
	 * @param is
	 */
	public void setIssue(int[] is) {
		issue = is;
	}

	/**
	 * @param is
	 */
	public void setWrite(int[] is) {
		write = is;
	}

	public void setStructural(int[] is) {
		structural = is;
	}

	/**
	 * @return
	 */
	public int getD() {
		return d;
	}

	/**
	 * @return
	 */
	public int getE() {
		return e;
	}

	/**
	 * @return
	 */
	public int getI() {
		return i;
	}

	/**
	 * @return
	 */
	public int getW() {
		return w;
	}

	public int getS() {
		return s;
	}

	/**
	 * @param i
	 */
	public void setD(int i) {
		d = i;
	}

	/**
	 * @param i
	 */
	public void setE(int i) {
		e = i;
	}

	/**
	 * @param i
	 */
	public void setI(int i) {
		this.i = i;
	}

	/**
	 * @param i
	 */
	public void setW(int i) {
		w = i;
	}

	public void setS(int i) {
		s = i;
	}

}
