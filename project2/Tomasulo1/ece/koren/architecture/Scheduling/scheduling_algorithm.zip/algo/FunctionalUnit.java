/*
 * Created on Nov 30, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package algo;

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class FunctionalUnit {
	private int integer;
	private int add;
	private int multiply;
	private int divide;
	
	public FunctionalUnit(int integer, int add, int multiply, int divide) {
		this.integer = integer;
		this.add = add;
		this.multiply = multiply;
		this.divide = divide;
	}
	
	public int getNoUnit(String operation) {
		if(operation.equalsIgnoreCase("LD") || operation.equalsIgnoreCase("SD"))
			return integer;
		else if (operation.equalsIgnoreCase("ADD") || operation.equalsIgnoreCase("SUB"))
			return add;
		else if (operation.equalsIgnoreCase("MULTIPLY"))
			return multiply;
		else if (operation.equalsIgnoreCase("DIVIDE"))
			return divide;
		
		return -1;
	}
	/**
	 * @return
	 */
	public int getAdd() {
		return add;
	}

	/**
	 * @return
	 */
	public int getDivide() {
		return divide;
	}

	/**
	 * @return
	 */
	public int getInteger() {
		return integer;
	}

	/**
	 * @return
	 */
	public int getMultiply() {
		return multiply;
	}

	/**
	 * @param i
	 */
	public void setAdd(int i) {
		add = i;
	}

	/**
	 * @param i
	 */
	public void setDivide(int i) {
		divide = i;
	}

	/**
	 * @param i
	 */
	public void setInteger(int i) {
		integer = i;
	}

	/**
	 * @param i
	 */
	public void setMultiply(int i) {
		multiply = i;
	}

}
