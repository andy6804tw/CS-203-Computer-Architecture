package algo;

/*
 * Created on Nov 26, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class InstructionNode {
	private int no;
	private Instruction instr;
	public int indegree;
	private Stages stages;
	
	private RefStages refNode;		// node number
	private RefStages refStages;	// which stage of the parent node
	
	public InstructionNode(Instruction instr, int no) {
		this.instr = instr;
		this.no = no;
		stages = new Stages();
		
		refNode = new RefStages();
		refStages = new RefStages();
		
		indegree = 0;
	}

	/**
	 * @return
	 */
	public Instruction getInstr() {
		return instr;
	}

	/**
	 * @return
	 */
	public int getNo() {
		return no;
	}

	/**
	 * @return
	 */
	public Stages getStages() {
		return stages;
	}

	/**
	 * @param instruction
	 */
	public void setInstr(Instruction instruction) {
		instr = instruction;
	}

	/**
	 * @param i
	 */
	public void setNo(int i) {
		no = i;
	}

	/**
	 * @param stages
	 */
	public void setStages(Stages stages) {
		this.stages = stages;
	}

	/**
	 * @return
	 */
	public RefStages getRefNode() {
		return refNode;
	}

	/**
	 * @return
	 */
	public RefStages getRefStages() {
		return refStages;
	}

	/**
	 * @param stages
	 */
	public void setRefNode(RefStages stages) {
		refNode = stages;
	}

	/**
	 * @param stages
	 */
	public void setRefStages(RefStages stages) {
		refStages = stages;
	}

}
