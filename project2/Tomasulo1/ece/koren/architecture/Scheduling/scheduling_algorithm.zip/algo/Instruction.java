package algo;
/*
 * Created on Nov 26, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Instruction {
	private String type;
	private String dest;
	private String src1;
	private String src2;
	private int numCycles;
	
	public Instruction() {
		
	}
	
	public Instruction(String type, String dest, String src1, String src2, int numCycles) {
		this.type = type;
		this.dest = dest;
		this.src1 = src1;
		this.src2 = src2;
		this.numCycles = numCycles;
	}
	/**
	 * @return
	 */
	public String getDest() {
		return dest;
	}

	/**
	 * @return
	 */
	public String getSrc1() {
		return src1;
	}

	/**
	 * @return
	 */
	public String getSrc2() {
		return src2;
	}

	/**
	 * @return
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param string
	 */
	public void setDest(String string) {
		dest = string;
	}

	/**
	 * @param string
	 */
	public void setSrc1(String string) {
		src1 = string;
	}

	/**
	 * @param string
	 */
	public void setSrc2(String string) {
		src2 = string;
	}

	/**
	 * @param string
	 */
	public void setType(String string) {
		type = string;
	}

	/**
	 * @return
	 */
	public int getNumCycles() {
		return numCycles;
	}

	/**
	 * @param i
	 */
	public void setNumCycles(int i) {
		numCycles = i;
	}

}
