/*
 * Created on Dec 22, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package algo;

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class PipelineUnit {
	private int load;
	private int add;
	private int multiply;
	private int divide;
	
	public PipelineUnit() {
		load = add = multiply = divide = 0;
	}
	
	public int getValue (String str) {
		if(str.equalsIgnoreCase("LD"))
			return load;
		if(str.equalsIgnoreCase("SD"))
			return load;
		if(str.equalsIgnoreCase("ADD"))
			return add;
		if(str.equalsIgnoreCase("SUB"))
			return add;
		if(str.equalsIgnoreCase("MULTIPLY"))
			return multiply;
		if(str.equalsIgnoreCase("DIVIDE"))
			return divide;
		
		// code should not reached here
		System.out.println("\n\nERROR\n\n");
		return -1;
	}
	
	/**
	 * @return
	 */
	public int getAdd() {
		return add;
	}

	/**
	 * @return
	 */
	public int getDivide() {
		return divide;
	}

	/**
	 * @return
	 */
	public int getLoad() {
		return load;
	}

	/**
	 * @return
	 */
	public int getMultiply() {
		return multiply;
	}

	/**
	 * @param i
	 */
	public void setAdd(int i) {
		add = i;
	}

	/**
	 * @param i
	 */
	public void setDivide(int i) {
		divide = i;
	}

	/**
	 * @param i
	 */
	public void setLoad(int i) {
		load = i;
	}

	/**
	 * @param i
	 */
	public void setMultiply(int i) {
		multiply = i;
	}

}
