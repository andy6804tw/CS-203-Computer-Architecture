/*
 * Created on Nov 30, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package algo;

import java.util.Iterator;

import structure.GraphListDirected;

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TomasuloInstructionGraph {
	private int maxCycle = 50;
	private int totalCycle = 0;
	private int numInstr;
	private InstructionNode instrNode[];
	private int count;
	private FunctionalUnit unit;
	private FunctionalUnit resStations;	
	private int pipeline;
	private PipelineUnit p;
	
	private GraphListDirected graph;

	public String timeChart[][];
	
	public TomasuloInstructionGraph(int numInstr,  PipelineUnit p, FunctionalUnit unit, FunctionalUnit resStations) {
		this.numInstr = numInstr;
		this.p = p;
		this.unit = unit;
		this.resStations = resStations;

		timeChart = new String[numInstr][maxCycle];
		for(int i=0; i<numInstr; i++)
			for(int j=0; j<maxCycle; j++)
				timeChart[i][j] = "";
		
		
		instrNode = new InstructionNode[numInstr];
		graph = new GraphListDirected();
		count = 0;
	}
	
	public void addInstr (InstructionNode node) {
		instrNode[count++] = node;
		graph.add(instrNode[count-1]);
	}
	
	public void generateDateHazardGraph() {
		for (int i=0; i<numInstr; i++) {
			String r1 = instrNode[i].getInstr().getDest();
			String r2 = instrNode[i].getInstr().getSrc1();
			String r3 = instrNode[i].getInstr().getSrc2();
			String r7 = instrNode[i].getInstr().getType();
			
			for (int j=i+1; j<numInstr; j++) {
				System.out.println("#Tomasulo: GenerateDataHazardGraph# i="+i +" j="+j);
				boolean flag = false;	// whether any dependency exist or not
				
				String r4 = instrNode[j].getInstr().getDest();
				String r5 = instrNode[j].getInstr().getSrc1();
				String r6 = instrNode[j].getInstr().getSrc2();
				String r8 = instrNode[j].getInstr().getType();
				
				if(r5.equalsIgnoreCase(r1) || r6.equalsIgnoreCase(r1)) {
					// RAW hazard - execute after stage 3 (execute) of prev instr
					// different rules for different algos
					instrNode[j].getRefNode().addExecDep(i);
					instrNode[j].getRefStages().addExecDep(3);	
					flag = true;	
					System.out.println("\t RAW Hazard");
				}
				System.out.println(" r8:"+r8+" r7:"+r7);
				if( (r8.equalsIgnoreCase(r7)) ||
					((r8.equalsIgnoreCase("LD") || r8.equalsIgnoreCase("SD")) && (r7.equalsIgnoreCase("LD") || r7.equalsIgnoreCase("SD"))) ||
					((r8.equalsIgnoreCase("ADD") || r8.equalsIgnoreCase("SUB")) && (r7.equalsIgnoreCase("ADD") || r7.equalsIgnoreCase("SUB")))
					) {
					// structural hazard - start after prev instr execution is over
					instrNode[j].getRefNode().addStructuralDep(i);
					instrNode[j].getRefStages().addStructuralDep(3);
					flag = true;
					System.out.println("\t Structural Hazard");
				}				
				
				if(flag) {
					graph.addEdge(instrNode[i], instrNode[j], "edge");
					instrNode[j].indegree++;
					System.out.println("\t Edge added");
				}
						
			}
		}
	}
	
	public void topologicalTraversal() {
		int cycle = 1;
		for (int i=0; i<numInstr; i++) {
			System.out.println("Cycle Number:"+cycle+" Count:"+i);
			
			int localCycle = cycle;
			InstructionNode node = findNodeZeroIndegree();
			System.out.println("\t InstrNo:"+node.getNo());
			pipeline = p.getValue(node.getInstr().getType());

			// Issue phase
			int highestDep = localCycle;
			if(node.getRefNode().getI() != -1) {
				for(int j=0; j<=node.getRefNode().getI(); j++) {
					if(highestDep < (instrNode[node.getRefNode().getIssue(j)].getStages().getStageCycle(node.getRefStages().getIssue(j)) + 1)) {
						highestDep = instrNode[node.getRefNode().getIssue(j)].getStages().getStageCycle(node.getRefStages().getIssue(j)) + 1;
					}
				}	
			}

			if(node.getRefNode().getS()!=-1) {
				int busy = 0;
				int diff = 100;
				int index = -1;
				for(int j=0; j<=node.getRefNode().getS(); j++) {
					if(highestDep <= instrNode[node.getRefNode().getStructural(j)].getStages().getWrite()) {  
						busy++;
						int tempDiff = instrNode[node.getRefNode().getStructural(j)].getStages().getWrite() - highestDep + 1;
						if(tempDiff < diff) {
							diff = tempDiff;
							index = node.getRefNode().getStructural(j);
						}
					}
				}
				int available = resStations.getNoUnit(instrNode[i].getInstr().getType()) - busy;
				System.out.println("#Tomasulo# Available:"+available+" Busy:"+busy);
				if (available <= 0) {
					highestDep = instrNode[index].getStages().getWrite() + 1;
				}
			}
			
			for(int j=localCycle; j<highestDep; j++) {
				timeChart[i][j] = "S";
			}
			localCycle = highestDep;
			
			if(i!=0) {
				int k = 1;	// 1 cycle required for issue
				for (int j=0; j<k; ) {
					int flag = 1;
					for(int l=0; l<i; l++)
						if(timeChart[i-1][localCycle+j].equalsIgnoreCase("I")) 
							flag = 0;
					if(flag == 0) {
						timeChart[i][localCycle+j] = "S";
						localCycle++;
					} else {
						j++;
					}
				}
			}

			System.out.println("#Tomasulo: Issue:"+localCycle);
			node.getStages().setIssue(localCycle);
			timeChart[i][localCycle] = "I";
			localCycle++;

			
			// No Decode hazard
/*			if(node.getRefNode().getD() != -1) {
				int highestDep = localCycle;
				System.out.println("\t Decode No:"+node.getRefNode().getD()+" cycle:"+highestDep);
				for(int j=0; j<=node.getRefNode().getD(); j++) {
					System.out.println("\t\t j="+j+" value:"+instrNode[node.getRefNode().getDecode(j)].getStages().getStageCycle(node.getRefStages().getDecode(j)) + 1);
					if(highestDep < (instrNode[node.getRefNode().getDecode(j)].getStages().getStageCycle(node.getRefStages().getDecode(j)) + 1)) {
						highestDep = instrNode[node.getRefNode().getDecode(j)].getStages().getStageCycle(node.getRefStages().getDecode(j)) + 1;
					}
				}
				localCycle = highestDep;
			}
*/
			node.getStages().setDecode(localCycle);
			timeChart[i][localCycle] = "D";
			localCycle++;
			
			// Execution phase
			highestDep = localCycle;
			if(node.getRefNode().getE() != -1) {	// RAW hazard
				for(int j=0; j<=node.getRefNode().getE(); j++) {
					if(highestDep < (instrNode[node.getRefNode().getExecEnd(j)].getStages().getStageCycle(node.getRefStages().getExecEnd(j)) + 1)) {
						highestDep = instrNode[node.getRefNode().getExecEnd(j)].getStages().getStageCycle(node.getRefStages().getExecEnd(j)) + 1;
					}
				}
			}
				
			if(node.getRefNode().getS()!=-1) {
				int busy = 0;
				int diff = 100;
				int index = -1;
				for(int j=0; j<=node.getRefNode().getS(); j++) {
					if((highestDep <= instrNode[node.getRefNode().getStructural(j)].getStages().getExecEnd() &&
							highestDep >= instrNode[node.getRefNode().getStructural(j)].getStages().getExecStart()) || 
							((highestDep + node.getInstr().getNumCycles() - 1) <= instrNode[node.getRefNode().getStructural(j)].getStages().getExecEnd() &&
								(highestDep + node.getInstr().getNumCycles() - 1) >= instrNode[node.getRefNode().getStructural(j)].getStages().getExecStart()))		
						busy++;
						int tempDiff = instrNode[node.getRefNode().getStructural(j)].getStages().getExecEnd() - highestDep + 1;
						if(tempDiff < diff) {
							diff = tempDiff;
							index = node.getRefNode().getStructural(j);
						}
				}
				
				if(pipeline==1) {
					// start the execution
				} else if (busy > 0 && pipeline == 0) {
					highestDep = instrNode[index].getStages().getExecEnd() + 1;
				}
			}
				
			for(int j=localCycle; j<highestDep; j++) {
				timeChart[i][j] = "S";
			}
			localCycle = highestDep;
			System.out.println("#Tomasulo: Exec:"+localCycle);
			node.getStages().setExecStart(localCycle);
			localCycle = localCycle + node.getInstr().getNumCycles() - 1;
			node.getStages().setExecEnd(localCycle);
			for(int j=highestDep; j<=localCycle; j++) 
				timeChart[i][j] = "E";
			localCycle++;
						
			// Write phase

			highestDep = localCycle;
			if(node.getRefNode().getW() != -1) {
				for(int j=0; j<=node.getRefNode().getW(); j++) {
					if(highestDep < (instrNode[node.getRefNode().getWrite(j)].getStages().getStageCycle(node.getRefStages().getWrite(j)) + 1)) {
						highestDep = instrNode[node.getRefNode().getWrite(j)].getStages().getStageCycle(node.getRefStages().getWrite(j)) + 1;
					}
				}
			}

			for(int j=localCycle; j<highestDep; j++) {
				timeChart[i][j] = "S";
			}
			highestDep = localCycle;
			if(i!=0) {
				int k = 1;	// 1 cycle required for decode
				for (int j=0; j<k; ) {
					int flag = 1;
					for(int l=0; l<i; l++)
						if(timeChart[i-1][localCycle+j].equalsIgnoreCase("W")) 
							flag = 0;
					if(flag == 0) {
						timeChart[i][localCycle+j] = "S";
						localCycle++;
					} else {
						j++;
					}
				}
			}
			System.out.println("#Tomasulo: Write:"+localCycle);
			timeChart[i][localCycle] = "W";
			node.getStages().setWrite(localCycle);
			totalCycle = localCycle;

			
			// execution of 1 instruction is complete			
			// remove this instr from the graph
			Iterator iterator = graph.neighbors(node);
			while(iterator.hasNext()) {
				InstructionNode temp = (InstructionNode) iterator.next();
				temp.indegree--;
			}
			graph.remove(node);
			
			// increment the cycle counter
			cycle++;
		}
		
	}
	
	InstructionNode findNodeZeroIndegree() {
		InstructionNode node = null;
		for(int i=0; i<numInstr; i++) {
			if(graph.contains(instrNode[i]) && instrNode[i].indegree==0)
				return (InstructionNode) instrNode[i];
		}
		System.out.println("No zero indegree node found");
		return node;
	}
	/**
	 * @return
	 */
	public GraphListDirected getGraph() {
		return graph;
	}

	/**
	 * @return
	 */
	public InstructionNode getInstrNode(int index) {
		return instrNode[index];
	}

	/**
	 * @return
	 */
	public int getNumInstr() {
		return numInstr;
	}

	/**
	 * @param directed
	 */
	public void setGraph(GraphListDirected directed) {
		graph = directed;
	}

	/**
	 * @param nodes
	 */
	public void setInstrNode(InstructionNode[] nodes) {
		instrNode = nodes;
	}

	/**
	 * @param i
	 */
	public void setNumInstr(int i) {
		numInstr = i;
	}

	/**
	 * @return
	 */
	public int getTotalCycle() {
		return totalCycle;
	}

	/**
	 * @param i
	 */
	public void setTotalCycle(int i) {
		totalCycle = i;
	}

}
