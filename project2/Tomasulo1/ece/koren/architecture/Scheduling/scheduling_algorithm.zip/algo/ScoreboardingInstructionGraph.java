package algo;
import java.util.Iterator;

import structure.GraphListDirected;

/*
 * Created on Nov 26, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ScoreboardingInstructionGraph {
	private int numInstr;
	private InstructionNode instrNode[];
	private int count;
	private int maxCycle = 50;
	private int totalCycle = 0;
	private int pipeline;
	private PipelineUnit p;
	private GraphListDirected graph;
	private FunctionalUnit unit;

	public String timeChart[][];

	public ScoreboardingInstructionGraph(int numInstr, PipelineUnit p, FunctionalUnit unit) {
		this.numInstr = numInstr;
		this.p = p;
		this.unit = unit;
		
		instrNode = new InstructionNode[numInstr];
		timeChart = new String[numInstr][maxCycle];
		for(int i=0; i<numInstr; i++)
			for(int j=0; j<maxCycle; j++)
				timeChart[i][j] = "";
		
		graph = new GraphListDirected();
		count = 0;
	}
	
	public void addInstr (InstructionNode node) {
		instrNode[count++] = node;
		graph.add(instrNode[count-1]);
	}
	
	public void generateDateHazardGraph() {
		for (int i=0; i<numInstr; i++) {
			String r1 = instrNode[i].getInstr().getDest();
			String r2 = instrNode[i].getInstr().getSrc1();
			String r3 = instrNode[i].getInstr().getSrc2();
			String r7 = instrNode[i].getInstr().getType();
			
			for (int j=i+1; j<numInstr; j++) {
				System.out.println("#Scoreboarding: GenerateDataHazardGraph# i="+i +" j="+j);
				boolean flag = false;	// whether any dependency exist or not
				
				String r4 = instrNode[j].getInstr().getDest();
				String r5 = instrNode[j].getInstr().getSrc1();
				String r6 = instrNode[j].getInstr().getSrc2();
				String r8 = instrNode[j].getInstr().getType();

				if(r4.equalsIgnoreCase(r2) || r4.equalsIgnoreCase(r3)) {
					//	WAR hazard - write after stage 2 (decode) of prev instr
					instrNode[j].getRefNode().addWriteDep(i);
					instrNode[j].getRefStages().addWriteDep(2);
					flag = true;	
					System.out.println("\t WAR Hazard");
				}
				
				if(r4.equalsIgnoreCase(r1)) {
					// WAW hazard - write after stage 4 (weite) of prev instr
					instrNode[j].getRefNode().addWriteDep(i);
					instrNode[j].getRefStages().addWriteDep(4);	
					flag = true;	
					System.out.println("\t WAW Hazard");
				}
				
				if(r5.equalsIgnoreCase(r1) || r6.equalsIgnoreCase(r1)) {
					// RAW hazard - execute after stage 3 (execute) of prev instr
					// different rules for different algos
					instrNode[j].getRefNode().addExecDep(i);
					instrNode[j].getRefStages().addExecDep(3);	
					flag = true;	
					System.out.println("\t RAW Hazard");
				}
				
				if( (r8.equalsIgnoreCase(r7)) ||
					((r8.equalsIgnoreCase("LD") || r8.equalsIgnoreCase("SD")) && (r7.equalsIgnoreCase("LD") || r7.equalsIgnoreCase("SD"))) ||
					((r8.equalsIgnoreCase("ADD") || r8.equalsIgnoreCase("SUB")) && (r7.equalsIgnoreCase("ADD") || r7.equalsIgnoreCase("SUB")))
					) {
					// structural hazard - start after prev instr execution is over
					instrNode[j].getRefNode().addStructuralDep(i);
					instrNode[j].getRefStages().addStructuralDep(3);
					flag = true;
					System.out.println("\t Structural Hazard");
				}
				
				if(flag) {
					graph.addEdge(instrNode[i], instrNode[j], "edge");
					instrNode[j].indegree++;
					System.out.println("\t Edge added");
				}
						
			}
		}
	}
	
	public void topologicalTraversal() {
		int cycle = 1;
		for (int i=0; i<numInstr; i++) {
			System.out.println("Cycle Number:"+cycle+" Count:"+i);
			
			int localCycle = cycle;
			int tempCycle;
			InstructionNode node = findNodeZeroIndegree();
			System.out.println("\t InstrNo:"+node.getNo());
			pipeline = p.getValue(node.getInstr().getType());

			// Issue phase
			int highestDep = localCycle;
			if(node.getRefNode().getI() != -1) {
				for(int j=0; j<=node.getRefNode().getI(); j++) {
					if(highestDep < (instrNode[node.getRefNode().getIssue(j)].getStages().getStageCycle(node.getRefStages().getIssue(j)) + 1)) {
						highestDep = instrNode[node.getRefNode().getIssue(j)].getStages().getStageCycle(node.getRefStages().getIssue(j)) + 1;
					}
				}	
			}
			for(int j=localCycle; j<highestDep; j++) {
				timeChart[i][j] = "S";
			}
			localCycle = highestDep;
			if(i!=0) {
				int k = 1;	// 1 cycle required for issue
				for (int j=0; j<k; ) {
					int flag = 1;
					for(int l=0; l<i; l++)
						if(timeChart[i-1][localCycle+j].equalsIgnoreCase("I")) 
							flag = 0;
					if(flag == 0) {
						timeChart[i][localCycle+j] = "S";
						localCycle++;
					} else {
						j++;
					}
				}
			}
			timeChart[i][localCycle] = "I";
			node.getStages().setIssue(localCycle);
			localCycle++;

			highestDep = localCycle;
			// Decode phase
			if(node.getRefNode().getD() != -1) {
				System.out.println("\t Decode No:"+node.getRefNode().getD()+" cycle:"+highestDep);
				for(int j=0; j<=node.getRefNode().getD(); j++) {
					System.out.println("\t\t j="+j+" value:"+instrNode[node.getRefNode().getDecode(j)].getStages().getStageCycle(node.getRefStages().getDecode(j)) + 1);
					if(highestDep < (instrNode[node.getRefNode().getDecode(j)].getStages().getStageCycle(node.getRefStages().getDecode(j)) + 1)) {
						highestDep = instrNode[node.getRefNode().getDecode(j)].getStages().getStageCycle(node.getRefStages().getDecode(j)) + 1;
					}
				}
			}
			for(int j=localCycle; j<highestDep; j++) {
				timeChart[i][j] = "S";
			}
			localCycle = highestDep;
			if(i!=0) {
				int k = 1;	// 1 cycle required for decode
				for (int j=0; j<k; ) {
					int flag = 1;
					for(int l=0; l<i; l++)
						if(timeChart[i-1][localCycle+j].equalsIgnoreCase("D")) 
							flag = 0;
					if(flag == 0) {
						timeChart[i][localCycle+j] = "S";
						localCycle++;
					} else {
						j++;
					}
				}
			}
			timeChart[i][localCycle] = "D";
			node.getStages().setDecode(localCycle);
			localCycle++;
			
			// Execution phase
			highestDep = localCycle;
			if(node.getRefNode().getE() != -1) {
				for(int j=0; j<=node.getRefNode().getE(); j++) {
					if(highestDep < (instrNode[node.getRefNode().getExecEnd(j)].getStages().getStageCycle(node.getRefStages().getExecEnd(j)) + 1)) {
						highestDep = instrNode[node.getRefNode().getExecEnd(j)].getStages().getStageCycle(node.getRefStages().getExecEnd(j)) + 1;
					}
				}
			}
			
			if(node.getRefNode().getS()!=-1) {
				
				int busy = 0;
				int diff = 100;
				int index = -1;
				for(int j=0; j<=node.getRefNode().getS(); j++) {
					if((highestDep <= instrNode[node.getRefNode().getStructural(j)].getStages().getExecEnd() &&
							highestDep >= instrNode[node.getRefNode().getStructural(j)].getStages().getExecStart()) || 
							((highestDep + node.getInstr().getNumCycles() - 1) <= instrNode[node.getRefNode().getStructural(j)].getStages().getExecEnd() &&
								(highestDep + node.getInstr().getNumCycles() - 1) >= instrNode[node.getRefNode().getStructural(j)].getStages().getExecStart()))		
						busy++;
						int tempDiff = instrNode[node.getRefNode().getStructural(j)].getStages().getExecEnd() - highestDep + 1;
						if(tempDiff < diff) {
							diff = tempDiff;
							index = node.getRefNode().getStructural(j);
						}
				}
				int available = unit.getNoUnit(instrNode[i].getInstr().getType()) - busy;
				System.out.println("Inside structual hazard. available:"+available);
				
				if(pipeline==1) {
					// start the execution
				} else if (available > 0 && pipeline == 0){
					// start the execution
				} else if (available <= 0 && pipeline == 0) {
					highestDep = instrNode[index].getStages().getExecEnd() + 1;
				}
			}
			
			for(int j=localCycle; j<highestDep; j++) {
				timeChart[i][j] = "S";
			}
			localCycle = highestDep;
			node.getStages().setExecStart(localCycle);
			if(i!=0) {
				int k = node.getInstr().getNumCycles();	//  cycles required for execution
				for (int j=0; j<k; ) {
					timeChart[i][localCycle+j] = "E";
					j++;
				}
			} else {
				int k = node.getInstr().getNumCycles();	//  cycles required for execution
				for (int j=0; j<k; ) {
					timeChart[i][localCycle+j] = "E";
					j++;
				}				
			}

			localCycle = localCycle + node.getInstr().getNumCycles() - 1;
			node.getStages().setExecEnd(localCycle);
			localCycle++;
			
			// Write phase
			highestDep = localCycle;
			if(node.getRefNode().getW() != -1) {
				for(int j=0; j<=node.getRefNode().getW(); j++) {
					if(highestDep < (instrNode[node.getRefNode().getWrite(j)].getStages().getStageCycle(node.getRefStages().getWrite(j)) + 1)) {
						highestDep = instrNode[node.getRefNode().getWrite(j)].getStages().getStageCycle(node.getRefStages().getWrite(j)) + 1;
					}
				}
			}
			for(int j=localCycle; j<highestDep; j++) {
				timeChart[i][j] = "S";
			}
			localCycle = highestDep;
			if(i!=0) {
				int k = 1;	// 1 cycle required for decode
				for (int j=0; j<k; ) {
					int flag = 1;
					for(int l=0; l<i; l++)
						if(timeChart[l][localCycle+j].equalsIgnoreCase("S") || timeChart[i-1][localCycle+j].equalsIgnoreCase("W")) 
							flag = 0;
					if(flag == 0) {
						timeChart[i][localCycle+j] = "S";
						localCycle++;
					} else {
						j++;
					}
				}
			}
			timeChart[i][localCycle] = "W";
			node.getStages().setWrite(localCycle);
			totalCycle = localCycle;
			
			// execution of 1 instruction is complete			
			// remove this instr from the graph
			Iterator iterator = graph.neighbors(node);
			while(iterator.hasNext()) {
				InstructionNode temp = (InstructionNode) iterator.next();
				temp.indegree--;
			}
			graph.remove(node);
			
			// increment the cycle counter
			cycle++;
		}
		
	}
	
	InstructionNode findNodeZeroIndegree() {
		InstructionNode node = null;
		for(int i=0; i<numInstr; i++) {
			System.out.println("\tInstrNo:"+i+" Indegree:"+instrNode[i].indegree);
			if(graph.contains(instrNode[i]) && instrNode[i].indegree==0)
				return (InstructionNode) instrNode[i];
		}
		System.out.println("No zero indegree node found");
		return node;
	}
	/**
	 * @return
	 */
	public GraphListDirected getGraph() {
		return graph;
	}

	/**
	 * @return
	 */
	public InstructionNode getInstrNode(int index) {
		return instrNode[index];
	}

	/**
	 * @return
	 */
	public int getNumInstr() {
		return numInstr;
	}

	/**
	 * @param directed
	 */
	public void setGraph(GraphListDirected directed) {
		graph = directed;
	}

	/**
	 * @param nodes
	 */
	public void setInstrNode(InstructionNode[] nodes) {
		instrNode = nodes;
	}

	/**
	 * @param i
	 */
	public void setNumInstr(int i) {
		numInstr = i;
	}

	/**
	 * @return
	 */
	public int getTotalCycle() {
		return totalCycle;
	}

	/**
	 * @param i
	 */
	public void setTotalCycle(int i) {
		totalCycle = i;
	}

}
