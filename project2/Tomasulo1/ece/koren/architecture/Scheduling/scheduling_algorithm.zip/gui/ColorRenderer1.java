/*
 * Created on Dec 22, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.table.TableCellRenderer;

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ColorRenderer1 extends JLabel
						   implements TableCellRenderer {
	
	Border selectedBorder = null;

	public Component getTableCellRendererComponent(
							JTable table, Object value,
							boolean isSelected, boolean hasFocus,
							int row, int column) {
		
		
		String str = (String) value;
		setText(str);
		if (str.equalsIgnoreCase("s")) {
			setForeground(new Color(255, 0, 0));
		} else 
			setForeground(new Color(100, 100, 0));
		
    
//		setToolTipText("its working"); //Discussed in the following section
		return this;
	}

}