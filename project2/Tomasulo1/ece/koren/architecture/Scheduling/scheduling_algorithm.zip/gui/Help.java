/*
 * Created on Dec 22, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package gui;


import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
class Help extends JFrame
	implements ActionListener
{
	JLabel labelA;
	JLabel labelB;
	JLabel labelC;
	JLabel labelD;
	JLabel labelE;
	JLabel labelF;
	
	JTextArea text[];
	JTextArea textArea; 
	
	final String QUIT = "QUIT";
	AlgoApplet applet;

	Help(AlgoApplet applet)
	{
		super("The Credits");
		this.applet = null;
		this.applet = applet;
		Container contentPane = getContentPane();
		contentPane.setLayout(new BoxLayout(contentPane, 1));
		
		labelA = new JLabel("University of Massachusetts @ Amherst");
		labelB = new JLabel("Final Project for Computer Architecture");
		labelE = new JLabel("Professor Israel Koren :");
		labelF = new JLabel("http://www.ecs.umass.edu/ece/koren");
		labelC = new JLabel("By Niranjan :");
		labelD = new JLabel("http://www.people.umass.edu/niranjan");
		
		//Create a text area.
		textArea = new JTextArea("This is an editable JTextArea");

		JPanel textPanel = new JPanel();
		textPanel.setLayout(new GridLayout(20, 1));		
		text = new JTextArea[20];
		
		text[0] = new JTextArea("Time Chart for different scheduling algorithms");

		text[1] = new JTextArea("Following are the steps to use this software:");

		text[2] = new JTextArea("Step1: Selection of MIPS instruction set");
		text[3] = new JTextArea("Insert MPIS instructions by pressing �Insert Instruction�. After an instruction is inserted, its type, destination and sources can be changed. Last instruction can be removed by pressing �Remove Instruction�.");

		text[4] = new JTextArea("Step 2: Configuring number of cycles for different execution"); 
		text[5] = new JTextArea("The number of cycles for execution of each function can be configured. For e.g.: number of cycles to execute �Multiply� can be chosen from 1 to 10 cycles.");

		text[6] = new JTextArea("Step 3: Configuring number of functional units.");
		text[7] = new JTextArea("The number of functional units for each function can be configured. For e.g.: number of functional units for load/store can be chosen from 1 to 10.");

		text[8] = new JTextArea("Step 4: Configuring number of reservation stations (only for Tomasulo)");
		text[9] = new JTextArea("The number of reservation stations for each functional unit in Tomasulo dynamic scheduling algorithms can be configured. For e.g: number of reservation stations for add/sub can be chosen between 1 and 10.");

		text[10] = new JTextArea("Step 5: Configuring whether functional units are pipelined or not.");
		text[11] = new JTextArea("Different functional units can be separately configured for pipeline or not pipeline execution.");

		text[12] = new JTextArea("Step 6: Selection of scheduling algorithms");
		text[13] = new JTextArea("The software implements static scheduling with forwarding and without forwarding and dynamic scheduling namely Tomasulo and Scoreboarding. It provides flexibility to chose one or more scheduling algorithms.");

		text[14] = new JTextArea("Step 7: Start the execution");
		text[15] = new JTextArea("The execution can be started by pressing �Execute�. It executes the chosen algorithm in the background and shows the empty time chart.");

		text[16] = new JTextArea("Step 8: Viewing results");
		text[17] = new JTextArea("Time chart can be view step-by-step by pressing �Step-by-Step� on the basis of cycle. The total time chart can be seen any time by pressing �Final�. The time chart is shown in different colors for different scheduling algorithms and the stall cycles are shown in dark red color to clearly differentiate it from other pipeline stages and helps in differentiating across the algorithms.");

		text[18] = new JTextArea("The whole process can be reset anytime by pressing �Reset� button. Then you can start by going to Step 1.");


		for(int i=0; i<19; i++) {
			text[i].setLineWrap(true);
			text[i].setWrapStyleWord(true);
			textPanel.add(text[i]);
		}
		contentPane.add(textPanel);
		
		textArea.setFont(new Font("Serif", Font.ITALIC, 16));
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		JScrollPane areaScrollPane = new JScrollPane(textArea);
		areaScrollPane.setVerticalScrollBarPolicy(
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		areaScrollPane.setPreferredSize(new Dimension(250, 250));
		areaScrollPane.setBorder(
			BorderFactory.createCompoundBorder(
				BorderFactory.createCompoundBorder(
								BorderFactory.createTitledBorder("Plain Text"),
								BorderFactory.createEmptyBorder(5,5,5,5)),
				areaScrollPane.getBorder()));

		contentPane.add(textArea);	
		contentPane.add(labelA);
		contentPane.add(labelB);
		contentPane.add(Box.createRigidArea(new Dimension(0, 10)));
		contentPane.add(labelC);
		contentPane.add(labelD);
		contentPane.add(Box.createRigidArea(new Dimension(0, 10)));
		contentPane.add(labelE);
		contentPane.add(labelF);
		contentPane.add(Box.createRigidArea(new Dimension(0, 10)));
		JPanel choicePanel = new JPanel();
		JButton ok = new JButton("OK");
		ok.setActionCommand("QUIT");
		ok.addActionListener(this);
		choicePanel.add(ok);
		choicePanel.setBackground(new Color(60, 60, 100));
		contentPane.add(choicePanel);
		java.awt.event.WindowListener listener = new WindowAdapter() {

			public void windowClosing(WindowEvent e)
			{
				dispose();
			}

		};
		addWindowListener(listener);
		pack();
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getActionCommand().equals("QUIT"))
			dispose();
	}

}