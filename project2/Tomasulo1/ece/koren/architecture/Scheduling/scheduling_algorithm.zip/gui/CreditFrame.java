/*
 * Created on Dec 22, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package gui;


import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
class CreditFrame extends JFrame
	implements ActionListener
{
	JLabel labelA;
	JLabel labelB;
	JLabel labelC;
	JLabel labelD;
	JLabel labelE;
	JLabel labelF;
	final String QUIT = "QUIT";
	AlgoApplet applet;

	CreditFrame(AlgoApplet applet)
	{
		super("The Credits");
		this.applet = null;
		this.applet = applet;
		Container contentPane = getContentPane();
		contentPane.setLayout(new BoxLayout(contentPane, 1));
		labelA = new JLabel("University of Massachusetts @ Amherst");
		labelB = new JLabel("Final Project for Computer Architecture");
		labelE = new JLabel("Professor Israel Koren :");
		labelF = new JLabel("http://www.ecs.umass.edu/ece/koren");
		labelC = new JLabel("By Niranjan :");
		labelD = new JLabel("http://www.people.umass.edu/niranjan");
		contentPane.add(labelA);
		contentPane.add(labelB);
		contentPane.add(Box.createRigidArea(new Dimension(0, 10)));
		contentPane.add(labelC);
		contentPane.add(labelD);
		contentPane.add(Box.createRigidArea(new Dimension(0, 10)));
		contentPane.add(labelE);
		contentPane.add(labelF);
		contentPane.add(Box.createRigidArea(new Dimension(0, 10)));
		JPanel choicePanel = new JPanel();
		JButton ok = new JButton("OK");
		ok.setActionCommand("QUIT");
		ok.addActionListener(this);
		choicePanel.add(ok);
		choicePanel.setBackground(new Color(60, 60, 100));
		contentPane.add(choicePanel);
		java.awt.event.WindowListener listener = new WindowAdapter() {

			public void windowClosing(WindowEvent e)
			{
				dispose();
			}

		};
		addWindowListener(listener);
		pack();
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getActionCommand().equals("QUIT"))
			dispose();
	}

}