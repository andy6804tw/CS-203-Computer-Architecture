/*
 * Created on Nov 27, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package gui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import algo.FunctionalUnit;
import algo.Instruction;
import algo.InstructionNode;
import algo.PipelineUnit;
import algo.ScoreboardingInstructionGraph;
import algo.TomasuloInstructionGraph;
import algo.WithForwardingInstructionGraph;
import algo.WithoutForwardingInstructionGraph;

/**
 * @author niran
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
//public class AlgoFrame extends Applet implements ActionListener, ItemListener{
public class AlgoApplet extends JApplet implements ActionListener, ItemListener{
	final int HEIGHT = 450;
	final int WIDTH  = 410;
	private int numMaxInstr = 10;	// allowed maximum number of instruction
	private int numInstr = 0;
	private int cycle = 0;
	private String instrSet[];
	private int totalCycle = 0;
	private int numColumn = 59;
	
	int current_numInstr;
	
	private WithForwardingInstructionGraph withforwardingInstrGraph;
	private WithoutForwardingInstructionGraph withoutforwardingInstrGraph;
	private TomasuloInstructionGraph tomasuloInstrGraph;
	private ScoreboardingInstructionGraph scoreboardingInstrGraph;
	
	private InstructionNode withforwardingInstrNode;
	private InstructionNode withoutforwardingInstrNode;
	private InstructionNode tomasuloInstrNode;
	private InstructionNode scoreboardingInstrNode;
	
	private String instrCode[] = {"LD", "SD", "ADD", "SUB", "MULTIPLY", "DIVIDE"};
	private String destReg[] = {"F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"};
	private String srcReg[] = {"F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7"};
	private String offsetReg[] = {"F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
	
	private String registerFP[] = {"F0", "F2", "F4", "F6", "F8", "F10", "F12", "F14"};
	private String registerInt[] = {"R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7"};      
	//private String numbers[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"};	
	private String numberCycles[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
	
	private String maxInstr[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}; // currently not used
			
	private JComboBox instr[];
	private JComboBox dest[];
	private JComboBox src1[];
	private JComboBox src2[];

	private JLabel instrCountLabel;
	private JComboBox instrCount;
	private JButton insertInstr;
	private JButton removeInstr;
	
	// for number of cycles for each instruction
	private JLabel execTimeLabel;
	private JLabel load_storeLabel;
	private JLabel add_subLabel;
	private JLabel multiplyLabel;
	private JLabel divideLabel;
	private JComboBox load_store;
	private JComboBox add_sub;
	private JComboBox multiply;
	private JComboBox divide;
	// for number of functional units
	private JLabel execTimeLabel1;
	private JLabel load_storeLabel1;
	private JLabel add_subLabel1;
	private JLabel multiplyLabel1;
	private JLabel divideLabel1;
	private JComboBox load_store1;
	private JComboBox add_sub1;
	private JComboBox multiply1;
	private JComboBox divide1;
	// for reservation stations
	private JLabel execTimeLabel2;
	private JLabel load_storeLabel2;
	private JLabel add_subLabel2;
	private JLabel multiplyLabel2;
	private JLabel divideLabel2;
	private JComboBox load_store2;
	private JComboBox add_sub2;
	private JComboBox multiply2;
	private JComboBox divide2;
	
	private JLabel pipelineLabel;
	private JLabel pipelineLabel1;
	private JLabel pipelineLabel2;
	private JLabel pipelineLabel3;
	private JLabel pipelineLabel4;
	private JCheckBox pipeline1;
	private JCheckBox pipeline2;
	private JCheckBox pipeline3;
	private JCheckBox pipeline4;
	
	private JButton execute;
	private JButton reset;

	private JCheckBox withForwarding;	
	private JCheckBox withoutForwarding;	
	private JCheckBox tomasulo;	
	private JCheckBox scoreboarding;	

	private JButton stepExecution;
	private JButton finalExecution;
	private JButton credits;
	private JButton help;
	
	private JTable withForwardingTable;
	private JTable withoutForwardingTable;
	private JTable tomasuloTable;
	private JTable scoreboardingTable;
	private JScrollPane sp1, sp2, sp3, sp4;
	
	private AlgoTableModel tm1, tm2, tm3, tm4;

	JPanel instrPanel;
	JPanel tablePanel;

	private Container c;
	
	public AlgoApplet() {
		setSize(1000,1000);
		
		c = getContentPane();
		//c.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		//c.setLayout(new GridLayout(6,1));
		//setBorder(BorderFactory.createBevelBorder(10));

		instrPanel = new JPanel();
		instrPanel.setLayout(new GridLayout(10,4));
		instrPanel.setBorder(BorderFactory.createBevelBorder(40));
		
		instr = new JComboBox[numMaxInstr];
		dest = new JComboBox[numMaxInstr];
		src1 = new JComboBox[numMaxInstr];
		src2 = new JComboBox[numMaxInstr];
		
		for(int i=0; i<numMaxInstr; i++) {
			instr[i] = new JComboBox(instrCode);
			instr[i].setName("a" + i);
			instr[i].setSelectedIndex(2);
			instr[i].addItemListener(this);
			dest[i] = new JComboBox(destReg);
			dest[i].setName("b" + i);
			dest[i].addActionListener(this);
			src1[i] = new JComboBox(destReg);
			src1[i].setName("c" + i);
			src1[i].addActionListener(this);
			src2[i] = new JComboBox(destReg);
			src2[i].setName("d" + i);
			src2[i].addActionListener(this);

			instr[i].setVisible(false);			
			dest[i].setVisible(false);			
			src1[i].setVisible(false);			
			src2[i].setVisible(false);			

			instrPanel.add(instr[i]);
			instrPanel.add(dest[i]);
			instrPanel.add(src1[i]);
			instrPanel.add(src2[i]);
		}
		
		JPanel instrCountPanel = new JPanel();
		instrCountPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 2));
		instrCountLabel = new JLabel("Number of Instructions:");
		//instrCountPanel.add(instrCountLabel);
		instrCount = new JComboBox(maxInstr);
		instrCount.addActionListener(this);
		//instrCountPanel.add(instrCount);
		insertInstr = new JButton("Insert Instruction");
		insertInstr.setName("Insert Instruction");
		//insertInstr.setForeground(new Color(200, 50, 0));
		insertInstr.addActionListener(this);
		instrCountPanel.add(insertInstr);
		removeInstr = new JButton("Remove Instruction");
		removeInstr.setName("Remove Instruction");
		//removeInstr.setForeground(new Color(200, 00, 50));
		removeInstr.addActionListener(this);
		instrCountPanel.add(removeInstr);
		
		JPanel controlPanel1 = new JPanel();
		controlPanel1.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 2));
		execute = new JButton("Execute");
		execute.setName("execute");
		execute.addActionListener(this);
		controlPanel1.add(execute);
		reset = new JButton("Reset");
		reset.setName("reset");
		reset.addActionListener(this);
		controlPanel1.add(reset);
		
		JPanel cyclePanel = new JPanel();		
		//cyclePanel.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));
		cyclePanel.setLayout(new GridLayout(2,1));
		JPanel cyclePanel1 = new JPanel();		
		cyclePanel1.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));
		JPanel cyclePanel2 = new JPanel();		
		cyclePanel2.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));


		execTimeLabel = new JLabel("Number of Cycles to execute:");
		execTimeLabel.setForeground(new Color(150, 0, 0));
		cyclePanel1.add(execTimeLabel);
		
		load_storeLabel = new JLabel("Load/Store");
		load_store = new JComboBox(numberCycles);
		load_store.setName("loadCycle");
		load_store.setSelectedIndex(0);
		load_store.addActionListener(this);
		cyclePanel2.add(load_storeLabel);
		cyclePanel2.add(load_store);
		
		add_subLabel = new JLabel("Add/Sub");
		add_sub = new JComboBox(numberCycles);
		add_sub.setName("addCycle");
		add_sub.setSelectedIndex(1);
		add_sub.addActionListener(this);
		cyclePanel2.add(add_subLabel);
		cyclePanel2.add(add_sub);
		
		multiplyLabel = new JLabel("Multiply");
		multiply = new JComboBox(numberCycles);
		multiply.setName("multiplyCycle");
		multiply.setSelectedIndex(2);
		multiply.addActionListener(this);
		cyclePanel2.add(multiplyLabel);
		cyclePanel2.add(multiply);
		
		divideLabel = new JLabel("Divide");
		divide = new JComboBox(numberCycles);
		divide.setName("divideCycle");
		divide.setSelectedIndex(4);
		divide.addActionListener(this);
		cyclePanel2.add(divideLabel);
		cyclePanel2.add(divide);
				
		cyclePanel.add(cyclePanel1);		
		cyclePanel.add(cyclePanel2);		

		JPanel unitPanel = new JPanel();		
		//unitPanel.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));
		unitPanel.setLayout(new GridLayout(2,1));
		JPanel unitPanel1 = new JPanel();		
		unitPanel1.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));
		JPanel unitPanel2 = new JPanel();		
		unitPanel2.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));

		execTimeLabel1 = new JLabel("Number of functionals unit:");
		execTimeLabel1.setForeground(new Color(0, 150, 0));
		unitPanel1.add(execTimeLabel1);
		
		load_storeLabel1 = new JLabel("Load/Store");
		load_store1 = new JComboBox(numberCycles);
		load_store1.setName("loadUnit");
		load_store1.addActionListener(this);
		unitPanel2.add(load_storeLabel1);
		unitPanel2.add(load_store1);
		
		add_subLabel1 = new JLabel("Add/Sub");
		add_sub1 = new JComboBox(numberCycles);
		add_sub1.setName("addUnit");
		add_sub1.addActionListener(this);
		unitPanel2.add(add_subLabel1);
		unitPanel2.add(add_sub1);
		
		multiplyLabel1 = new JLabel("Multiply");
		multiply1 = new JComboBox(numberCycles);
		multiply1.setName("multiplyUnit");
		multiply1.addActionListener(this);
		unitPanel2.add(multiplyLabel1);
		unitPanel2.add(multiply1);
		
		divideLabel1 = new JLabel("Divide");
		divide1 = new JComboBox(numberCycles);
		divide1.setName("divideUnit");
		divide1.addActionListener(this);
		unitPanel2.add(divideLabel1);
		unitPanel2.add(divide1);

		unitPanel.add(unitPanel1);
		unitPanel.add(unitPanel2);
		
		JPanel resPanel = new JPanel();		
		//resPanel.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));
		resPanel.setLayout(new GridLayout(2,1));
		JPanel resPanel1 = new JPanel();		
		resPanel1.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));
		JPanel resPanel2 = new JPanel();		
		resPanel2.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));

		execTimeLabel2 = new JLabel("Number of reservation stations (for tomasulo):");
		execTimeLabel2.setForeground(new Color(0, 0, 150));
		resPanel1.add(execTimeLabel2);
		
		load_storeLabel2 = new JLabel("Load/Store");
		load_store2 = new JComboBox(numberCycles);
		load_store2.setName("loadRes");
		load_store2.setSelectedIndex(1);
		load_store2.addActionListener(this);
		resPanel2.add(load_storeLabel2);
		resPanel2.add(load_store2);
		
		add_subLabel2 = new JLabel("Add/Sub");
		add_sub2 = new JComboBox(numberCycles);
		add_sub2.setName("addRes");
		add_sub2.setSelectedIndex(1);
		add_sub2.addActionListener(this);
		resPanel2.add(add_subLabel2);
		resPanel2.add(add_sub2);
		
		multiplyLabel2 = new JLabel("Multiply");
		multiply2 = new JComboBox(numberCycles);
		multiply2.setName("multiplyRes");
		multiply2.setSelectedIndex(1);
		multiply2.addActionListener(this);
		resPanel2.add(multiplyLabel2);
		resPanel2.add(multiply2);
		
		divideLabel2 = new JLabel("Divide");
		divide2 = new JComboBox(numberCycles);
		divide2.setName("divideRes");
		divide2.setSelectedIndex(1);
		divide2.addActionListener(this);
		resPanel2.add(divideLabel2);
		resPanel2.add(divide2);
		
		resPanel.add(resPanel1);
		resPanel.add(resPanel2);

		JPanel pipelinePanel = new JPanel();		
		pipelinePanel.setLayout(new GridLayout(2,1));
		JPanel pipelinePanel1 = new JPanel();		
		pipelinePanel1.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));
		JPanel pipelinePanel2 = new JPanel();		
		pipelinePanel2.setLayout(new FlowLayout(FlowLayout.LEADING, 10, 2));

		pipelineLabel = new JLabel("Pipleline Functional Units");
		pipelineLabel.setForeground(new Color(100, 150, 150));
		pipelinePanel1.add(pipelineLabel);
			
		pipeline1 = new JCheckBox("Load/Store");
		pipeline1.setSelected(true);
		pipelinePanel2.add(pipeline1);
		
		pipeline2 = new JCheckBox("Add/Sub");
		pipeline2.setSelected(true);
		pipelinePanel2.add(pipeline2);
		
		pipeline3 = new JCheckBox("Multiply");
		pipeline3.setSelected(true);
		pipelinePanel2.add(pipeline3);
		
		pipeline4 = new JCheckBox("Divide");
		pipeline4.setSelected(true);
		pipelinePanel2.add(pipeline4);
		
		pipelinePanel.add(pipelinePanel1);
		pipelinePanel.add(pipelinePanel2);
		
		JPanel algoPanel = new JPanel();
		algoPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10,5));
		
		withForwarding = new JCheckBox("Static - With Forwarding");
		withForwarding.setSelected(true);
		withForwarding.addActionListener(this);
		algoPanel.add(withForwarding);
		withoutForwarding = new JCheckBox("Static - Without Forwarding");
		withoutForwarding.setSelected(false);
		withoutForwarding.addActionListener(this);
		algoPanel.add(withoutForwarding);
		tomasulo = new JCheckBox("Dynamic - Tomasulo");
		tomasulo.setSelected(false);
		tomasulo.addActionListener(this);
		algoPanel.add(tomasulo);
		scoreboarding = new JCheckBox("Dynamic - Scoreboarding");
		scoreboarding.setSelected(false);
		scoreboarding.addActionListener(this);
		algoPanel.add(scoreboarding);
		
		JPanel controlPanel2 = new JPanel();
		controlPanel2.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
		stepExecution = new JButton("Step-by-Step");
		stepExecution.setName("step");
		stepExecution.addActionListener(this);
		controlPanel2.add(stepExecution);

		finalExecution = new JButton("Complete");
		finalExecution.setName("Complete");
		finalExecution.addActionListener(this);
		stepExecution.setEnabled(false);
		finalExecution.setEnabled(false);
		controlPanel2.add(finalExecution);

		help = new JButton("Help");
		help.setName("Help");
		help.addActionListener(this);
		//controlPanel2.add(help);
				
		credits = new JButton("Credits");
		credits.setName("Credits");
		credits.addActionListener(this);
		controlPanel2.add(credits);
		
		tablePanel = new JPanel();
		tablePanel.setLayout(new GridLayout(4, 1, 5, 5));
		
		tm1 = new AlgoTableModel();
		withForwardingTable = new JTable(tm1);
		try {
			withForwardingTable.setDefaultRenderer(Class.forName("java.lang.String"), new ColorRenderer1());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Error: Class not found");
			e.printStackTrace();
		}
		withForwardingTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		sp1 = new JScrollPane(withForwardingTable);
		sp1.setBackground(new Color(100,100,100));		
		
		tm2 = new AlgoTableModel();
		withoutForwardingTable = new JTable(tm2);
		try {
			withoutForwardingTable.setDefaultRenderer(Class.forName("java.lang.String"), new ColorRenderer2());
		} catch (ClassNotFoundException e) {
			System.out.println("Error: Class not found");
			e.printStackTrace();
		}
		withoutForwardingTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		sp2 = new JScrollPane(withoutForwardingTable);
		sp2.setBackground(new Color(150,150,100));
		
		tm3 = new AlgoTableModel();
		tomasuloTable = new JTable(tm3);
		try {
			tomasuloTable.setDefaultRenderer(Class.forName("java.lang.String"), new ColorRenderer3());
		} catch (ClassNotFoundException e) {
			System.out.println("Error: Class not found");
			e.printStackTrace();
		}
		tomasuloTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		sp3 = new JScrollPane(tomasuloTable);
		
		tm4 = new AlgoTableModel();
		scoreboardingTable = new JTable(tm4);
		try {
			scoreboardingTable.setDefaultRenderer(Class.forName("java.lang.String"), new ColorRenderer4());
		} catch (ClassNotFoundException e) {
			System.out.println("Error: Class not found");
			e.printStackTrace();
		}
		scoreboardingTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		sp4 = new JScrollPane(scoreboardingTable);
		scoreboardingTable.setPreferredScrollableViewportSize(new Dimension(500, 70));
	
		c.setLayout(new GridLayout(2,1));
	
		JPanel upperPanel = new JPanel();
		upperPanel.setLayout(new GridLayout(1,2));
		
		//c.add(instrPanel);
		
		JPanel middlePanel = new JPanel();
		middlePanel.setLayout(new GridLayout(8,1));
		middlePanel.add(instrCountPanel);
		middlePanel.add(controlPanel1);
		middlePanel.add(cyclePanel);
		middlePanel.add(unitPanel);
		middlePanel.add(resPanel);
		middlePanel.add(pipelinePanel);
		middlePanel.add(algoPanel);
		middlePanel.add(controlPanel2);
		//c.add(middlePanel);
		
		Border mpBorder1 = BorderFactory.createRaisedBevelBorder();
		TitledBorder mpTBorder1 = BorderFactory.createTitledBorder(mpBorder1, "Control Panel");
		mpTBorder1.setTitleColor(new Color(200, 00, 00));
		Border mpBorder2 = BorderFactory.createRaisedBevelBorder();
		TitledBorder mpTBorder2 = BorderFactory.createTitledBorder(mpBorder2, "Instruction Panel");
		mpTBorder2.setTitleColor(new Color(00, 200, 00));
		Border mpBorder3 = BorderFactory.createRaisedBevelBorder();
		TitledBorder mpTBorder3 = BorderFactory.createTitledBorder(mpBorder3, "Time Chart");
		mpTBorder3.setTitleColor(new Color(00, 00, 200));

		middlePanel.setBorder(mpTBorder1);
		instrPanel.setBorder(mpTBorder2);
		tablePanel.setBorder(mpTBorder3);
		
		upperPanel.add(middlePanel);
		upperPanel.add(instrPanel);
		//upperPanel.setBorder(new Borde\)
		c.add(upperPanel);
		
		c.add(tablePanel);
		
//		resetFirstPhase();		
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();
		System.out.println(action);
		//current_numInstr = Integer.parseInt(instrCount.getSelectedItem().toString());
		current_numInstr = numInstr;
		
		System.out.println("Instr Count:"+current_numInstr);
		if(action.equalsIgnoreCase("Insert Instruction")) {
			if(numInstr <numMaxInstr) {
				instr[numInstr].setVisible(true);			
				dest[numInstr].setVisible(true);			
				src1[numInstr].setVisible(true);			
				src2[numInstr].setVisible(true);			
	
				numInstr++;
				instrPanel.updateUI();
			}

		} else if(action.equalsIgnoreCase("Remove Instruction") && current_numInstr>0) {
				numInstr--;
				instr[numInstr].setVisible(false);			
				dest[numInstr].setVisible(false);			
				src1[numInstr].setVisible(false);			
				src2[numInstr].setVisible(false);			

				instrPanel.updateUI();

		} else if(action.equals("Execute")  && current_numInstr>0 ) {
			pressExecute();
			
			tablePanel.remove(sp1);
			tablePanel.remove(sp2);
			tablePanel.remove(sp3);
			tablePanel.remove(sp4);
			tablePanel.updateUI();			
			
			cycle = 1;
			totalCycle = 1;
			
			// Intruction set initialization
			FunctionalUnit unit = new FunctionalUnit(Integer.parseInt((String)load_store1.getSelectedItem()),Integer.parseInt((String)add_sub1.getSelectedItem()), Integer.parseInt((String)multiply1.getSelectedItem()), Integer.parseInt((String)divide1.getSelectedItem()));
			FunctionalUnit resStations = new FunctionalUnit(Integer.parseInt((String)load_store2.getSelectedItem()),Integer.parseInt((String)add_sub2.getSelectedItem()), Integer.parseInt((String)multiply2.getSelectedItem()), Integer.parseInt((String)divide2.getSelectedItem()));
			
			PipelineUnit p = new PipelineUnit();
			if (pipeline1.isSelected()) p.setLoad(1);
			if (pipeline2.isSelected()) p.setAdd(1);
			if (pipeline3.isSelected()) p.setMultiply(1);
			if (pipeline4.isSelected()) p.setDivide(1);

			instrSet = new String[current_numInstr];			
			for(int i=0; i<current_numInstr; i++) {
				instrSet[i] = instr[i].getSelectedItem().toString() + " " +
						dest[i].getSelectedItem().toString() + ", " +
					src1[i].getSelectedItem().toString() + ", " +
					src2[i].getSelectedItem().toString();
			}
			
			
			
			if(withForwarding.isSelected()) {
				executeWithForwarding(p, unit);
				if(totalCycle < withforwardingInstrGraph.getTotalCycle())
					totalCycle = withforwardingInstrGraph.getTotalCycle();
					
				tablePanel.add(sp1);
				tm1.setData(current_numInstr);
				tm1.setRowCol(instrSet, "WithForwarding");
				withForwardingTable.setModel(tm1);
				withForwardingTable.getColumnModel().getColumn(0).setPreferredWidth(150);
				for (int i=1; i<numColumn; i++)
					withForwardingTable.getColumnModel().getColumn(i).setPreferredWidth(40);
				withForwardingTable.setForeground(new Color(50, 100, 150));
				//withForwardingTable.setForeground(new Color(0, 0, 200));
				withForwardingTable.repaint();
			}
			if(withoutForwarding.isSelected()) {
				executeWithoutForwarding(p, unit);
				if(totalCycle < withoutforwardingInstrGraph.getTotalCycle())
					totalCycle = withoutforwardingInstrGraph.getTotalCycle();
					
				tablePanel.add(sp2);
				tm2.setData(current_numInstr);
				tm2.setRowCol(instrSet, "WithoutForwarding");
				withoutForwardingTable.setModel(tm2);
				withoutForwardingTable.getColumnModel().getColumn(0).setPreferredWidth(150);
				for (int i=1; i<numColumn; i++)
					withoutForwardingTable.getColumnModel().getColumn(i).setPreferredWidth(40);
				withoutForwardingTable.setForeground(new Color(150, 100, 50));
				withoutForwardingTable.repaint();
			}
			if(tomasulo.isSelected()) {
				executeTomasulo(p, unit, resStations);
				if(totalCycle < tomasuloInstrGraph.getTotalCycle())
					totalCycle = tomasuloInstrGraph.getTotalCycle();
					
				tablePanel.add(sp3);
				tm3.setData(current_numInstr);
				tm3.setRowCol(instrSet, "Tomasulo");
				tomasuloTable.setModel(tm3);
				tomasuloTable.getColumnModel().getColumn(0).setPreferredWidth(150);
				for (int i=1; i<numColumn; i++)
					tomasuloTable.getColumnModel().getColumn(i).setPreferredWidth(40);
				tomasuloTable.setForeground(new Color(100, 50, 150));
				tomasuloTable.repaint();
			}
			if(scoreboarding.isSelected()) {
				executeScoreboarding(p, unit);
				if(totalCycle < scoreboardingInstrGraph.getTotalCycle())
					totalCycle = scoreboardingInstrGraph.getTotalCycle();
					
				tablePanel.add(sp4);
				tm4.setData(current_numInstr);
				tm4.setRowCol(instrSet, "Scoreboarding");
				scoreboardingTable.setModel(tm4);
				scoreboardingTable.getColumnModel().getColumn(0).setPreferredWidth(150);
				for (int i=1; i<numColumn; i++)
					scoreboardingTable.getColumnModel().getColumn(i).setPreferredWidth(40);

				scoreboardingTable.setForeground(new Color(0, 0, 150));
				scoreboardingTable.repaint();
			}
			System.out.println("\nTotal Cycle:"+totalCycle+"\n");
			tablePanel.updateUI();
			
		} else if (action.equals("Reset")) {
			pressReset();
			cycle = 0;
			totalCycle = 1;

			while(numInstr>0) {
				numInstr--; 
				instr[numInstr].setVisible(false);			
				dest[numInstr].setVisible(false);			
				src1[numInstr].setVisible(false);			
				src2[numInstr].setVisible(false);			
			}
			instrPanel.updateUI();
		
			tablePanel.remove(sp1);
			tablePanel.remove(sp2);
			tablePanel.remove(sp3);
			tablePanel.remove(sp4);
			tablePanel.updateUI();
			
		} else if (action.equals("Step-by-Step")) {
			
			if(withForwarding.isSelected()) {
				for(int i=0; i<current_numInstr; i++){
					tm1.setValueAt(withforwardingInstrGraph.timeChart[i][cycle], i, cycle);
				}
				withForwardingTable.setModel(tm1);
				withForwardingTable.repaint();
			}
			if (withoutForwarding.isSelected()) {
				for(int i=0; i<current_numInstr; i++){
					tm2.setValueAt(withoutforwardingInstrGraph.timeChart[i][cycle], i, cycle);
				}
				withoutForwardingTable.setModel(tm2);
				withoutForwardingTable.repaint();
			}
			if (tomasulo.isSelected()) {
				for(int i=0; i<current_numInstr; i++){
					tm3.setValueAt(tomasuloInstrGraph.timeChart[i][cycle], i, cycle);
				}
				tomasuloTable.setModel(tm3);
				tomasuloTable.repaint();
			} 
			if (scoreboarding.isSelected()) {
				for(int i=0; i<current_numInstr; i++){
					tm4.setValueAt(scoreboardingInstrGraph.timeChart[i][cycle], i, cycle);
				}
				scoreboardingTable.setModel(tm4);
				scoreboardingTable.repaint();
			}
			cycle++;
			if(cycle > totalCycle)
				pressReset();
								
		} else if (action.equals("Complete")) {

			if(withForwarding.isSelected()) {
				for(int i=0; i<current_numInstr; i++){
					for(int j=1; j<=totalCycle; j++)
						tm1.setValueAt(withforwardingInstrGraph.timeChart[i][j], i, j);
				}
				withForwardingTable.setModel(tm1);
				withForwardingTable.repaint();
			}
			if (withoutForwarding.isSelected()) {
				for(int i=0; i<current_numInstr; i++){
					for(int j=1; j<=totalCycle; j++)
						tm2.setValueAt(withoutforwardingInstrGraph.timeChart[i][j], i, j);
				}
				withoutForwardingTable.setModel(tm2);
				withoutForwardingTable.repaint();
			}
			if (tomasulo.isSelected()) {
				for(int i=0; i<current_numInstr; i++){
					for(int j=1; j<=totalCycle; j++)
						tm3.setValueAt(tomasuloInstrGraph.timeChart[i][j], i, j);
				}
				tomasuloTable.setModel(tm3);
				tomasuloTable.repaint();
			} 
			if (scoreboarding.isSelected()) {
				for(int i=0; i<current_numInstr; i++){
					for(int j=1; j<=totalCycle; j++)
						tm4.setValueAt(scoreboardingInstrGraph.timeChart[i][j], i, j);
				}
				scoreboardingTable.setModel(tm4);
				scoreboardingTable.repaint();
			}
			pressReset();
		} else if (action.equals("Credits")) {
			CreditFrame cf = new CreditFrame(this);
			cf.show();
		} else if (action.equals("Help")) {
			Help h = new Help(this);
			h.show();

		}

//		JCheckBox temp = (JCheckBox) e.getSource();
//		System.out.println(temp.isSelected());
		
//		JComboBox cb = (JComboBox)e.getSource();
//		String value = (String)cb.getSelectedItem();
//		String name = cb.getName();
//		System.out.println(name);
//		if(name.charAt(0) == 'a') {
//			System.out.println(name.charAt(1) - '0');
//			src1[name.charAt(1) - '0'] = new JComboBox(numbers);
//		}
 
	}
	
	public void executeWithForwarding(PipelineUnit p, FunctionalUnit unit) {
		withforwardingInstrGraph = new WithForwardingInstructionGraph(current_numInstr, p, unit);
			
		for(int i=0; i<current_numInstr; i++) {
			Instruction tempInstr = new Instruction(
				instr[i].getSelectedItem().toString(), 
				dest[i].getSelectedItem().toString(),
				src1[i].getSelectedItem().toString(),
				src2[i].getSelectedItem().toString(),
				getNumInstrCycle(instr[i].getSelectedItem().toString()));
			InstructionNode tempNode = new InstructionNode(tempInstr, i);
			withforwardingInstrGraph.addInstr(tempNode);
		}
			
		System.out.println("Instruction graph constructed...");
		withforwardingInstrGraph.generateDateHazardGraph();
		System.out.println("Instruction graph data hazards graph constructed...");
		withforwardingInstrGraph.topologicalTraversal();
		System.out.println("Instruction graph topological traversal completed...");
		for(int i=0; i<current_numInstr; i++) {
			System.out.println("Instr: "+instrSet[i] + "\n" +
				"\t Issue"+withforwardingInstrGraph.getInstrNode(i).getStages().getIssue() +
				"\t Decode"+withforwardingInstrGraph.getInstrNode(i).getStages().getDecode() +
				"\t Execute Start"+withforwardingInstrGraph.getInstrNode(i).getStages().getExecStart() +
				"\t Execute End"+withforwardingInstrGraph.getInstrNode(i).getStages().getExecEnd() +
				"\t Write"+withforwardingInstrGraph.getInstrNode(i).getStages().getWrite()) ;
		}
	}
	
	public void executeWithoutForwarding(PipelineUnit p, FunctionalUnit unit) {
		withoutforwardingInstrGraph = new WithoutForwardingInstructionGraph(current_numInstr, p, unit);
			
		for(int i=0; i<current_numInstr; i++) {
			Instruction tempInstr = new Instruction(
				instr[i].getSelectedItem().toString(), 
				dest[i].getSelectedItem().toString(),
				src1[i].getSelectedItem().toString(),
				src2[i].getSelectedItem().toString(),
				getNumInstrCycle(instr[i].getSelectedItem().toString()));
			InstructionNode tempNode = new InstructionNode(tempInstr, i);
			withoutforwardingInstrGraph.addInstr(tempNode);
		}
			
		System.out.println("Instruction graph constructed...");
		withoutforwardingInstrGraph.generateDateHazardGraph();
		System.out.println("Instruction graph data hazards graph constructed...");
		withoutforwardingInstrGraph.topologicalTraversal();
		System.out.println("Instruction graph topological traversal completed...");
		for(int i=0; i<current_numInstr; i++) {
			System.out.println("Instr: "+instrSet[i] + "\n" +
				"\t Issue"+withoutforwardingInstrGraph.getInstrNode(i).getStages().getIssue() +
				"\t Decode"+withoutforwardingInstrGraph.getInstrNode(i).getStages().getDecode() +
				"\t Execute Start"+withoutforwardingInstrGraph.getInstrNode(i).getStages().getExecStart() +
				"\t Execute End"+withoutforwardingInstrGraph.getInstrNode(i).getStages().getExecEnd() +
				"\t Write"+withoutforwardingInstrGraph.getInstrNode(i).getStages().getWrite()) ;
		}
	}
	
	private void executeTomasulo(PipelineUnit p, FunctionalUnit unit, FunctionalUnit resStations) {
		tomasuloInstrGraph = new TomasuloInstructionGraph(current_numInstr, p, unit, resStations);
			
		for(int i=0; i<current_numInstr; i++) {
			Instruction tempInstr = new Instruction(
				instr[i].getSelectedItem().toString(), 
				dest[i].getSelectedItem().toString(),
				src1[i].getSelectedItem().toString(),
				src2[i].getSelectedItem().toString(),
				getNumInstrCycle(instr[i].getSelectedItem().toString()));
			InstructionNode tempNode = new InstructionNode(tempInstr, i);
			tomasuloInstrGraph.addInstr(tempNode);
		}
			
		System.out.println("Instruction graph constructed...");
		tomasuloInstrGraph.generateDateHazardGraph();
		System.out.println("Instruction graph data hazards graph constructed...");
		tomasuloInstrGraph.topologicalTraversal();
		System.out.println("Instruction graph topological traversal completed...");
		for(int i=0; i<current_numInstr; i++) {
			System.out.println("Instr: "+instrSet[i] + "\n" +
				"\t Issue"+tomasuloInstrGraph.getInstrNode(i).getStages().getIssue() +
				"\t Decode"+tomasuloInstrGraph.getInstrNode(i).getStages().getDecode() +
				"\t Execute Start"+tomasuloInstrGraph.getInstrNode(i).getStages().getExecStart() +
				"\t Execute End"+tomasuloInstrGraph.getInstrNode(i).getStages().getExecEnd() +
				"\t Write"+tomasuloInstrGraph.getInstrNode(i).getStages().getWrite()) ;
		}
	}
	
	public void executeScoreboarding(PipelineUnit p, FunctionalUnit unit) {
		scoreboardingInstrGraph = new ScoreboardingInstructionGraph(current_numInstr, p, unit);
		for(int i=0; i<current_numInstr; i++) {
			Instruction tempInstr = new Instruction(
				instr[i].getSelectedItem().toString(), 
				dest[i].getSelectedItem().toString(),
				src1[i].getSelectedItem().toString(),
				src2[i].getSelectedItem().toString(),
				getNumInstrCycle(instr[i].getSelectedItem().toString()));
			InstructionNode tempNode = new InstructionNode(tempInstr, i);
			scoreboardingInstrGraph.addInstr(tempNode);
		}
			
		System.out.println("Instruction graph constructed...");
		scoreboardingInstrGraph.generateDateHazardGraph();
		System.out.println("Instruction graph data hazards graph constructed...");
		scoreboardingInstrGraph.topologicalTraversal();
		System.out.println("Instruction graph topological traversal completed...");
		for(int i=0; i<current_numInstr; i++) {
			System.out.println("Instr: "+instrSet[i] + "\n" +
				"\t Issue"+scoreboardingInstrGraph.getInstrNode(i).getStages().getIssue() +
				"\t Decode"+scoreboardingInstrGraph.getInstrNode(i).getStages().getDecode() +
				"\t Execute Start"+scoreboardingInstrGraph.getInstrNode(i).getStages().getExecStart() +
				"\t Execute End"+scoreboardingInstrGraph.getInstrNode(i).getStages().getExecEnd() +
				"\t Write"+scoreboardingInstrGraph.getInstrNode(i).getStages().getWrite()) ;
		}
	}

	private void pressExecute() {
		withForwarding.setEnabled(false);
		withoutForwarding.setEnabled(false);
		tomasulo.setEnabled(false);
		scoreboarding.setEnabled(false);

		load_store.setEnabled(false);
		add_sub.setEnabled(false);
		multiply.setEnabled(false);
		divide.setEnabled(false);
		
		load_store1.setEnabled(false);
		add_sub1.setEnabled(false);
		multiply1.setEnabled(false);
		divide1.setEnabled(false);

		load_store2.setEnabled(false);
		add_sub2.setEnabled(false);
		multiply2.setEnabled(false);
		divide2.setEnabled(false);

		pipeline1.setEnabled(false);
		pipeline2.setEnabled(false);
		pipeline3.setEnabled(false);
		pipeline4.setEnabled(false);

		instrCount.setEnabled(false);
		stepExecution.setEnabled(true);
		finalExecution.setEnabled(true);
	}
	
	private void pressReset() {
		withForwarding.setEnabled(true);
		withoutForwarding.setEnabled(true);
		tomasulo.setEnabled(true);
		scoreboarding.setEnabled(true);

		load_store.setEnabled(true);
		add_sub.setEnabled(true);
		multiply.setEnabled(true);
		divide.setEnabled(true);
		
		load_store1.setEnabled(true);
		add_sub1.setEnabled(true);
		multiply1.setEnabled(true);
		divide1.setEnabled(true);

		load_store2.setEnabled(true);
		add_sub2.setEnabled(true);
		multiply2.setEnabled(true);
		divide2.setEnabled(true);

		pipeline1.setEnabled(true);
		pipeline2.setEnabled(true);
		pipeline3.setEnabled(true);
		pipeline4.setEnabled(true);

		instrCount.setEnabled(true);
		stepExecution.setEnabled(false);
		finalExecution.setEnabled(false);

	}

	private int getNumInstrCycle(String type) {
		if(type.equalsIgnoreCase("SD")) {
			return Integer.parseInt((String)load_store.getSelectedItem());	
		} else if (type.equalsIgnoreCase("LD")) {
			return Integer.parseInt((String)load_store.getSelectedItem());				
		} else if (type.equalsIgnoreCase("ADD")) {
			return Integer.parseInt((String)add_sub.getSelectedItem());
		} else if (type.equalsIgnoreCase("SUB")) {
			return Integer.parseInt((String)add_sub.getSelectedItem());
		} else if (type.equalsIgnoreCase("MULTIPLY")) {
			return Integer.parseInt((String)multiply.getSelectedItem());
		} else if (type.equalsIgnoreCase("DIVIDE")) {
			return Integer.parseInt((String)divide.getSelectedItem());
		}
		
		System.out.println("ERROR");
		return -1;
	}
	
	public void itemStateChanged(ItemEvent e) {
		JComboBox source = (JComboBox) e.getItemSelectable();
		String name = source.getName();
		int num = Integer.parseInt(name.substring(1));
		String type = (String)source.getSelectedItem();
		System.out.println(source.getName()+"   "+num+"   "+type);

		if(type !=null && (type.equalsIgnoreCase("LD") || type.equalsIgnoreCase("SD"))) {
			System.out.println("Updating register value");

			src1[num].removeAllItems();
			for(int i=0; i<registerInt.length; i++)
				src1[num].addItem(String.valueOf(registerInt[i]));
			
			src2[num].removeAllItems();
			for(int i=0; i<numberCycles.length; i++)
				src2[num].addItem(String.valueOf(numberCycles[i]));
			
//			instrPanel.updateUI();	
		} else if (type!=null){
			src1[num].removeAllItems();
			for(int i=0; i<destReg.length; i++)
				src1[num].addItem(String.valueOf(destReg[i]));
			
			src2[num].removeAllItems();
			for(int i=0; i<destReg.length; i++)
				src2[num].addItem(String.valueOf(destReg[i]));

//			instrPanel.updateUI();	
		}
	}
	
	public static void main (String args[]) {
		AlgoApplet frame = new AlgoApplet();
		frame.setVisible(true);
		frame.repaint();
	}

}

