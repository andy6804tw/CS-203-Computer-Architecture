import java.awt.*;

public class HelpPanel extends Panel
{
    TextPanel helpPanel;

    public HelpPanel()
    {
	setLayout(new BorderLayout());
	helpPanel = new TextPanel();
	add(helpPanel, "Center");

	helpPanel.append("Help:", Color.red);
	helpPanel.appendNewLine("", Color.black);
	helpPanel.appendNewLine("About Reservation Table Analyzer:", Color.magenta);
	System.out.println("This software is....");
	helpPanel.appendNewLine("This software is used to analyze reservation tables with one or two tasks running on a pipeline", Color.white);
    }
}
