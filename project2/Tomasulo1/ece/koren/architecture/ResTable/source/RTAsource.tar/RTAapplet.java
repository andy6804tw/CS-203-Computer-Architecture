import java.applet.Applet;
import java.awt.*;

public class RTAapplet extends Applet
{
    RTA r;
    
    public void init()
    {
	r = new RTA();
    }
}
