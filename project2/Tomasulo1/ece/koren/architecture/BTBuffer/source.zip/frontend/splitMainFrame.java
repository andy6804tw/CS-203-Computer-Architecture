/*
 * Created on Jan 13, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package frontend;
import javax.swing.*;

import exception_classes.*;
import backend.*;
import java.awt.*;

/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class splitMainFrame 
{
	AssemblyLanguageParser alp;
	predictor pred;
	int step;
	
	ProgramInputComponent programInputComponent;
	BtbComponent btbComponent;
	RegistersDisplayComponent registersDisplayComponent;
		
	JSplitPane horizontalSplitPane;
	JSplitPane verticalSplitPane;

	Dimension frame_dimension;	
	Dimension programInputComponentDim, btbComponentDim, registersDisplayComponentDim;
	Dimension programInputComponentMinDim, btbComponentMinDim, registersDisplayComponentMinDim;
	
	public splitMainFrame(Dimension dim) throws ProgramInputComponentException
	{
		frame_dimension=dim;
		
		/**
		 * Find out dimensions for various panels
		 * before proceeding
		 */
		programInputComponentDim = new Dimension((int)(frame_dimension.getWidth()*1.0/2.0),(int)(frame_dimension.getHeight()*4.0/5.0));
		btbComponentDim = new Dimension((int)(frame_dimension.getWidth() - programInputComponentDim.getWidth()), (int)programInputComponentDim.getHeight());
		registersDisplayComponentDim = new Dimension((int)(frame_dimension.getWidth()),(int)(frame_dimension.getHeight() - programInputComponentDim.getHeight()));
		
		programInputComponentMinDim = new Dimension((int)(frame_dimension.getWidth()*1.0/4.0),(int)(frame_dimension.getHeight()*2.0/5.0));
		btbComponentMinDim = new Dimension((int)(frame_dimension.getWidth()*1.0/4.0),(int)(frame_dimension.getHeight()*2.0/5.0));
		registersDisplayComponentMinDim = new Dimension((int)(frame_dimension.getWidth()),(int)(frame_dimension.getHeight()*1.0/8.0));
		
		//Display the program Input Component - 0 means display combos, 1 means editor
		programInputComponent = new ProgramInputComponent(this, 0, frame_dimension, programInputComponentMinDim, programInputComponentDim);
				
		//Display the Branch Target Buffer Component
		btbComponent = new BtbComponent(this, frame_dimension, btbComponentMinDim, btbComponentDim);
				
		/**
		 * Split the top pane horizontally and include the btbPanel
		 * and the Program-Input Panel.
		 */
		horizontalSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, programInputComponent.getProgramInputScrollPane(), btbComponent.getBtbPanel());
		horizontalSplitPane.setOneTouchExpandable(true);
		horizontalSplitPane.setDividerLocation((int)(programInputComponentDim.getWidth()));
		horizontalSplitPane.setMinimumSize(new Dimension((int)frame_dimension.getWidth(),(int)(programInputComponentMinDim.getHeight())));
		
		//Display the Registers Display Component
		registersDisplayComponent = new RegistersDisplayComponent(null, this, 0, frame_dimension, registersDisplayComponentMinDim, registersDisplayComponentDim);
				
		/**
		 * Include the horizontally-split pane and make the registers-pane
		 * into the vertical-split pane.
		 */		
		verticalSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, horizontalSplitPane, registersDisplayComponent.getRegisterDisplayPanel());
		verticalSplitPane.setOneTouchExpandable(true);
		verticalSplitPane.setDividerLocation((int)(programInputComponentDim.getWidth()));
		verticalSplitPane.setPreferredSize(frame_dimension);
	}
	
	/**
	 * Returns the VerticalSplitPane. The top pane of this split pane
	 * has been horizontally split into the Program Input Pane and the
	 * Branch Target Buffer Pane
	 * @return
	 */
	public JComponent getSplitPane()
	{
		return verticalSplitPane;
	}
}
