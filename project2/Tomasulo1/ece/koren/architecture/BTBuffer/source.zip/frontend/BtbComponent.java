/*
 * Created on Jan 14, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package frontend;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import backend.*;


/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BtbComponent implements ActionListener
{
	JScrollPane btbScrollPane;
	JPanel btbPanel;
	JLabel program_ended_label, global_history_label;
	
	JTable btb_table;
	DefaultTableModel model;
	Vector rows, columns;
	
	splitMainFrame mainFrame;
	
	Dimension btbComponentMinDim, btbComponentDim, frame_dimension;
	
	public JButton cycle_by_cycle, step_branch, to_end, reset;
	
	public BtbComponent(splitMainFrame mf, Dimension dimension, Dimension minDim, Dimension dim)
	{
		mainFrame=mf;
		frame_dimension = dimension;
		
		/**
		 * Display the Branch Target Buffer Panel. Display in a
		 * table.
		 */
		btbComponentMinDim = minDim;
		btbComponentDim = dim;
		
		btbPanel = new JPanel();
		btbPanel.setLayout(new BoxLayout(btbPanel, BoxLayout.PAGE_AXIS));
		btbPanel.setMinimumSize(btbComponentMinDim);
		
		//Add the label
		btbPanel.add(Box.createRigidArea(new Dimension(0,15)));
		JLabel label_top_right=new JLabel("BRANCH TARGET BUFFER");
		label_top_right.setFont(new Font("Serif", Font.BOLD, 14));
		btbPanel.add(label_top_right);
		btbPanel.add(Box.createRigidArea(new Dimension(0,30)));
		
		//Add the Table now
		btbPanel.add(getTablePanel());
		btbPanel.add(Box.createRigidArea(new Dimension(0,10)));
		
		//Add Buttons now. Create a new panel for them
		btbPanel.add(getBTB_buttonsPanel());
		
		//Add the global history label
		global_history_label = new JLabel("");
		global_history_label.setFont(new Font("Serif", Font.BOLD, 14));
		btbPanel.add(Box.createRigidArea(new Dimension(0,10)));
		btbPanel.add(global_history_label);
				
		//Add the final label that program has ended
		program_ended_label = new JLabel("Program has completed execution!");
		program_ended_label.setFont(new Font("Serif", Font.BOLD, 14));
		btbPanel.add(Box.createRigidArea(new Dimension(0,10)));
		btbPanel.add(program_ended_label);
		
		program_ended_label.setVisible(false);
		//program_ended_label.setVisible(true);
	}
	/**
	 * Return the Branch Target Buffer Panel. The panel has a label
	 * for the Branch Target Buffer, a table corresponding to the 
	 * Branch Target Buffer and the buttons.
	 * @return
	 */
	public Component getBtbPanel()
	{
		return btbPanel;
	}
	
	/**
	 * Draws the Branch Target Buffer in the Branch Target Buffer
	 * Panel. The Branch Target Buffer is put in a Scroll Pane 
	 * which is returned
	 * @param frame_dimension
	 * @return btbPane
	 */
	public JScrollPane getTablePanel()
	{
		model = new DefaultTableModel();
		btb_table = new JTable(model);
		rows = new Vector();
		columns = new Vector();
		
		String[] columnNames = {"Tag Number", "Predicted Address", "Next Prediction", "Prediction Bits of Global BHTs"};
		addColumnsToTable(columnNames);
				
		model.setDataVector(rows, columns);
		btb_table = new JTable(model);
		btb_table.setRowSelectionAllowed(false);
				
		Dimension dim = new Dimension((int)(btbComponentDim.getWidth()),(int)(btbComponentDim.getHeight()*1.0/4.0));
		btb_table.setPreferredScrollableViewportSize(dim);
		btbScrollPane = new JScrollPane(btb_table);
		return btbScrollPane;
	}
	
	public void addColumnsToTable(String[] colName)
	{
		for(int i=0; i<colName.length; i++)
		{
			columns.addElement(colName[i]);
		}		
	}
	
	public void addRowsToTable(String[] rowNames)
	{
		Vector r = new Vector();
		for(int i=0;i<rowNames.length; i++)
		{
			r.addElement(rowNames[i]);
			//System.out.println("Here1");
		}
		rows.addElement(r);
		btb_table.addNotify();
	}
	/**
	 * This function creates the buttons in the Branch Target
	 * Buffer Panel. The buttons are put in a panel and the panel
	 * is returned.
	 * @return subBTBPanel
	 */
	public JPanel getBTB_buttonsPanel()
	{
		GridBagConstraints c = new GridBagConstraints();
		JPanel subBTBPanel = new JPanel(new GridBagLayout());
		
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.insets = new Insets(4, 4, 4, 15);
		cycle_by_cycle = new JButton("STEP INSTRUCTION");
		cycle_by_cycle.setActionCommand("step_instruction");
		cycle_by_cycle.addActionListener(this);
		cycle_by_cycle.setToolTipText("Click this button to run in steps of 1 instruction");
		cycle_by_cycle.setEnabled(false);
		subBTBPanel.add(cycle_by_cycle, c);
		
		c.gridx = 3;
		c.gridwidth = 3;
		c.insets = new Insets(4, 15, 4, 4);
		step_branch = new JButton("STEP BRANCH");
		step_branch.setActionCommand("step_branch");
		step_branch.addActionListener(this);
		step_branch.setToolTipText("Click this button to run in steps of branch instructions");
		step_branch.setEnabled(false);
		subBTBPanel.add(step_branch, c);
		
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.insets = new Insets(4, 4, 4, 15);
		to_end = new JButton("RUN TO END");
		to_end.setActionCommand("run_to_end");
		to_end.addActionListener(this);
		to_end.setToolTipText("Click this button to run to the end of the program");
		to_end.setEnabled(false);
		subBTBPanel.add(to_end, c);
		
		c.gridx = 3;
		c.gridy = 1;
		c.gridwidth = 3;
		c.insets = new Insets(4,15,4,4);
		reset = new JButton("RESET");
		reset.setActionCommand("reset");
		reset.addActionListener(this);
		reset.setToolTipText("Click this button to reset the system");
		reset.setEnabled(false);
		subBTBPanel.add(reset, c);
		
		/*
		c.gridx = 3;
		c.gridy = 1;
		c.gridwidth = 3;
		c.insets = new Insets(4, 15, 4, 4);
		JButton help = new JButton("HELP");
		subBTBPanel.add(help, c);
		*/
		
		return subBTBPanel;
	}
	
	public void actionPerformed(ActionEvent evt)
	{
		if("reset".equals(evt.getActionCommand()))
		{
			try
			{
				System.out.println("Here_Sugam");
				AssemblyLanguageParser.program_ends = false;
				mainFrame.alp = null;
				mainFrame.pred = null;
				mainFrame.step = 0;
				
				//Display the program Input Component - 0 means display combos, 1 means editor
				ProgramInputComponent new_programInputComponent = new ProgramInputComponent(mainFrame, 0, frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.programInputComponent = new_programInputComponent;
						
				//Display the Branch Target Buffer Component
				BtbComponent new_btbComponent = new BtbComponent(mainFrame, frame_dimension, btbComponentMinDim, btbComponentDim);
				mainFrame.btbComponent = new_btbComponent;
						
				/**
				 * Split the top pane horizontally and include the btbPanel
				 * and the Program-Input Panel.
				 */
				mainFrame.horizontalSplitPane.setLeftComponent(new_programInputComponent.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setRightComponent(new_btbComponent.getBtbPanel());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(mainFrame.programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
				
				//Display the Registers Display Component
				RegistersDisplayComponent new_registersDisplayComponent = new RegistersDisplayComponent(null, mainFrame, 0, frame_dimension, mainFrame.registersDisplayComponentMinDim, mainFrame.registersDisplayComponentDim);
				mainFrame.registersDisplayComponent = new_registersDisplayComponent;
				
				/**
				 * Include the horizontally-split pane and make the registers-pane
				 * into the vertical-split pane.
				 */		
				mainFrame.verticalSplitPane.setBottomComponent(new_registersDisplayComponent.getRegisterDisplayPanel());
				mainFrame.verticalSplitPane.setOneTouchExpandable(true);
				mainFrame.verticalSplitPane.setDividerLocation((int)(mainFrame.programInputComponentDim.getWidth()));
				mainFrame.verticalSplitPane.setPreferredSize(frame_dimension);
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(getBtbPanel(), e, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(e);
			}			
		}
		
		if("run_to_end".equals(evt.getActionCommand()))
		{
			try
			{
				mainFrame.step=2;
				mainFrame.alp.executeInstructions(2); //Run to the end
				
				//Display the editor highlighting the instruction being executed
				ProgramInputComponent new_component = new ProgramInputComponent(mainFrame, 1, mainFrame.frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.horizontalSplitPane.setLeftComponent(new_component.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(mainFrame.programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)mainFrame.frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
				
				//Refresh the registers display panel if the parameters choice has been input
				if(mainFrame.registersDisplayComponent.parameters_taken)
				{
					RegistersDisplayComponent new_component_registersComponent=new RegistersDisplayComponent(mainFrame.registersDisplayComponent, mainFrame, 1, mainFrame.frame_dimension, mainFrame.registersDisplayComponentMinDim, mainFrame.registersDisplayComponentMinDim);
					mainFrame.verticalSplitPane.setBottomComponent(new_component_registersComponent.getRegisterDisplayPanel());
					mainFrame.verticalSplitPane.setOneTouchExpandable(true);
				}
				
				//Display the program inside the editor
				mainFrame.programInputComponent.displayProgramInEditor(new_component);
				
				//Show the Branch Target Buffer
				rows.removeAllElements();
				
				for(int i=0; i<mainFrame.pred.btb.size(); i++)
				{
					int a[]=(int [])mainFrame.pred.btb.get(i);
					StringBuffer all_prediction_states = new StringBuffer("");
					int j;
					//Get the whole Branch History Table
					for(j=0; j<((int)Math.pow(2.0, (double) mainFrame.pred.no_global_bits))-1;j++)
					{
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 0)
							all_prediction_states.append(" N*  ,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 1)
							all_prediction_states.append(" N*T,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 2)
							all_prediction_states.append(" T*N,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 3)
							all_prediction_states.append(" T*  ,");
					}
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 0)
						all_prediction_states.append(" N*");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 1)
						all_prediction_states.append(" N*T");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 2)
						all_prediction_states.append(" T*N");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 3)
						all_prediction_states.append(" T*");
					
					//Get the predictions state that govern the prediction.
					String prediction_state=new String("");
					int bht_no = mainFrame.pred.get_local_bht_no(mainFrame.alp.global_history);
					System.out.println("bht_no: "+bht_no);
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 0)
						prediction_state = new String("Not Taken"); //new String("N*");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 1)
						prediction_state = new String("Not Taken"); //new String("N*T");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 2)
						prediction_state = new String("Taken"); //new String("T*N");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 3)
						prediction_state = new String("Taken"); //new String("T*");
										
					String str[];
					if(a[0]==-1)
						str=new String[]{"","","",""};
					else
						str=new String[]{a[0]+"",a[1]+"",prediction_state,all_prediction_states.toString()};
					addRowsToTable(str);										
				}
				if(AssemblyLanguageParser.program_ends || mainFrame.alp.PC >= mainFrame.alp.instructions.size())
					program_ended_label.setVisible(true);
				
				if(mainFrame.pred.no_global_bits > 0)
				{
					String history = get_history(mainFrame.alp.global_history);
					//System.out.println("Global History of Branches: " + history);
					global_history_label.setText("Global History of Branches: " + history);
				}
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(getBtbPanel(), e, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(e);
			}
		}
		if("step_branch".equals(evt.getActionCommand()))
		{
			try
			{
				mainFrame.step = 1;
				mainFrame.alp.executeInstructions(1); //Increase in steps of branch instruction
				
				//Display the editor highlighting the instruction being executed
				ProgramInputComponent new_component = new ProgramInputComponent(mainFrame, 1, mainFrame.frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.horizontalSplitPane.setLeftComponent(new_component.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(mainFrame.programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)mainFrame.frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
				
				//Refresh the registers display panel if parameters choice has been input
				if(mainFrame.registersDisplayComponent.parameters_taken)
				{
					RegistersDisplayComponent new_component_registersComponent=new RegistersDisplayComponent(mainFrame.registersDisplayComponent, mainFrame, 1, mainFrame.frame_dimension, mainFrame.registersDisplayComponentMinDim, mainFrame.registersDisplayComponentMinDim);
					mainFrame.verticalSplitPane.setBottomComponent(new_component_registersComponent.getRegisterDisplayPanel());
					mainFrame.verticalSplitPane.setOneTouchExpandable(true);
				}
				
				//Display the program inside the editor
				mainFrame.programInputComponent.displayProgramInEditor(new_component);
				
				//Show the Branch Target Buffer
				rows.removeAllElements();
				
				for(int i=0; i<mainFrame.pred.btb.size(); i++)
				{
					int a[]=(int [])mainFrame.pred.btb.get(i);
					StringBuffer all_prediction_states = new StringBuffer("");
					int j;
					//Get the whole Branch History Table
					for(j=0; j<((int)Math.pow(2.0, (double) mainFrame.pred.no_global_bits))-1;j++)
					{
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 0)
							all_prediction_states.append(" N*  ,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 1)
							all_prediction_states.append(" N*T,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 2)
							all_prediction_states.append(" T*N,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 3)
							all_prediction_states.append(" T*  ,");
					}
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 0)
						all_prediction_states.append(" N*");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 1)
						all_prediction_states.append(" N*T");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 2)
						all_prediction_states.append(" T*N");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 3)
						all_prediction_states.append(" T*");
					
					//Get the predictions state that govern the prediction.
					String prediction_state=new String("");
					int bht_no = mainFrame.pred.get_local_bht_no(mainFrame.alp.global_history);
					System.out.println("bht_no: "+bht_no);
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 0)
						prediction_state = new String("Not Taken"); //new String("N*");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 1)
						prediction_state = new String("Not Taken"); //new String("N*T");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 2)
						prediction_state = new String("Taken"); //new String("T*N");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 3)
						prediction_state = new String("Taken"); //new String("T*");
										
					String str[];
					if(a[0]==-1)
						str=new String[]{"","","",""};
					else
						str=new String[]{a[0]+"",a[1]+"",prediction_state,all_prediction_states.toString()};
					addRowsToTable(str);				
				}
				if(mainFrame.pred.no_global_bits > 0)
				{
					String history = get_history(mainFrame.alp.global_history);
					//System.out.println("Global History of Branches: " + history);
					global_history_label.setText("Global History of Branches: " + history);
				}
				if(AssemblyLanguageParser.program_ends || mainFrame.alp.PC >= mainFrame.alp.instructions.size())
					program_ended_label.setVisible(true);
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(getBtbPanel(), e, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(e);
			}
		}
		if("step_instruction".equals(evt.getActionCommand()))
		{
			try
			{
				mainFrame.step = 0;
				mainFrame.alp.executeInstructions(0); //Increase in steps of instruction
				//mainFrame.alp.showInstructions();
				//System.out.println("Instr. " + mainFrame.alp.PC);
				
				//Display the editor highlighting the instruction being executed
				ProgramInputComponent new_component = new ProgramInputComponent(mainFrame, 1, mainFrame.frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.horizontalSplitPane.setLeftComponent(new_component.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(mainFrame.programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)mainFrame.frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
				
				//Refresh the registers display panel if parameters choice has been input
				if(mainFrame.registersDisplayComponent.parameters_taken)
				{
					RegistersDisplayComponent new_component_registersComponent=new RegistersDisplayComponent(mainFrame.registersDisplayComponent, mainFrame, 1, mainFrame.frame_dimension, mainFrame.registersDisplayComponentMinDim, mainFrame.registersDisplayComponentMinDim);
					mainFrame.verticalSplitPane.setBottomComponent(new_component_registersComponent.getRegisterDisplayPanel());
					mainFrame.verticalSplitPane.setOneTouchExpandable(true);
				}
				
				//Display the program inside the editor
				mainFrame.programInputComponent.displayProgramInEditor(new_component);
				
				//Show the Branch Target Buffer
				rows.removeAllElements();
				
				for(int i=0; i<mainFrame.pred.btb.size(); i++)
				{
					int a[]=(int [])mainFrame.pred.btb.get(i);
					StringBuffer all_prediction_states = new StringBuffer("");
					int j;
					//Get the whole Branch History Table
					for(j=0; j<((int)Math.pow(2.0, (double) mainFrame.pred.no_global_bits))-1;j++)
					{
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 0)
							all_prediction_states.append(" N*  ,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 1)
							all_prediction_states.append(" N*T,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 2)
							all_prediction_states.append(" T*N,");
						if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 3)
							all_prediction_states.append(" T*  ,");
					}
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 0)
						all_prediction_states.append(" N*");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 1)
						all_prediction_states.append(" N*T");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 2)
						all_prediction_states.append(" T*N");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(j))).get(i))).intValue() == 3)
						all_prediction_states.append(" T*");
					
					//Get the predictions state that govern the prediction.
					String prediction_state=new String("");
					int bht_no = mainFrame.pred.get_local_bht_no(mainFrame.alp.global_history);
					System.out.println("bht_no: "+bht_no);
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 0)
						prediction_state = new String("Not Taken"); //new String("N*");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 1)
						prediction_state = new String("Not Taken"); //new String("N*T");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 2)
						prediction_state = new String("Taken"); //new String("T*N");
					if(((Integer)(((ArrayList)(mainFrame.pred.global_bht.get(bht_no))).get(i))).intValue() == 3)
						prediction_state = new String("Taken"); //new String("T*");
										
					String str[];
					if(a[0]==-1)
						str=new String[]{"","","",""};
					else
						str=new String[]{a[0]+"",a[1]+"",prediction_state,all_prediction_states.toString()};
					addRowsToTable(str);					
				}
				if(AssemblyLanguageParser.program_ends || mainFrame.alp.PC >= mainFrame.alp.instructions.size())
					program_ended_label.setVisible(true);

				if(mainFrame.pred.no_global_bits > 0)
				{
					String history = get_history(mainFrame.alp.global_history);
					//System.out.println("Global History of Branches: " + history);
					global_history_label.setText("Global History of Branches: " + history);
				}				
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(getBtbPanel(), e, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(e);
			}
		}
	}
	String get_history(String global_history)
	{
		StringBuffer decision=new StringBuffer("");
		String refined_history = global_history.substring(4-mainFrame.pred.no_global_bits);
		int i;
		for(i=0; i<mainFrame.pred.no_global_bits-1; i++)
		{
			if(refined_history.charAt(i)=='0')
				decision.append("Not Taken , ");
			else
				decision.append("Taken, ");
		}
		if(refined_history.charAt(i)=='0')
			decision.append("Not Taken");
		else
			decision.append("Taken");
		
		return new String(decision);
	}
}
