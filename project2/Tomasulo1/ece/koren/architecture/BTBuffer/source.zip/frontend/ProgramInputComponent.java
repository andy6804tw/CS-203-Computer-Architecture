/*
 * Created on Jan 14, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package frontend;
import backend.*;
import javax.swing.*;
import exception_classes.*;
import java.awt.*;
import javax.swing.text.*;
import java.awt.event.*;
import java.util.*;
/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ProgramInputComponent implements ActionListener
{
	JScrollPane programInputScrollPane, programInputEditorScrollPane;
	JPanel programInputPanel, programInputEditorButtonsPanel;
	JTextPane editor;
	JButton go_button_editor, back_button_editor, editor_button_combos, go_button_combos;
	
	ArrayList instruction_components;
	ArrayList instructions;
			
	splitMainFrame mainFrame;
	
	JComboBox local_bits_combo, global_bits_combo, no_btb_entries_combo;
		
	Dimension programInputComponentDim, programInputComponentMinDim;
	
	public static final int NO_INSTRUCTIONS = 12;
	String instrs[] = {"", "MOV", "ADD", "SUB", "MULT", "DIV", "MOD", "BEQ", "BNE", "BLE", "BGE", "BGT", "BLT", "END"};
	
	public ProgramInputComponent(splitMainFrame mf, int index, Dimension frame_dimension, Dimension minDim, Dimension dim) throws ProgramInputComponentException
	{
		mainFrame = mf;
		
		programInputComponentMinDim = minDim;
		programInputComponentDim = dim;
		
		build_programInput_combos();
		
				
		/**
		 * Display the Program Input Panel. First Display combo boxes
		 * for reading in small programs. If it is a larger program, an
		 * option to input the program in an editor is given
		 */
		
		//Display the combo boxes Input Panel
		if(index==0)
		{
			programInputScrollPane = new JScrollPane(getProgramInputCombosPanel());
			display_default_program_combo(this);
		}
		//Display the Editor Panel
		else if(index==1)
		{
			programInputScrollPane = new JScrollPane(getEditorPanel());
			display_default_program_editor(this);
		}
		//Display the branch target buffer input parameters Panel
		else if(index==2)
			programInputScrollPane = new JScrollPane(getBtbInputParametersPanel());
		else
			throw new ProgramInputComponentException("Invalid index for choosing display");
	}
	
	/**
	 * This function inputs the default program to be displayed in the 
	 * editor/combo-boxes.
	 */
	public void display_default_program_editor(ProgramInputComponent new_component)
	{
		Document doc = new_component.editor.getDocument();
		//Load the program into the editor
		try
		{
			doc.insertString(doc.getLength(), "MOV R32 #2;\n", new_component.editor.getStyle("regular"));
			doc.insertString(doc.getLength(), "label1: BEQ R32 #2 label;\n", new_component.editor.getStyle("regular"));
			doc.insertString(doc.getLength(), "label: MOV R31 R32;\n", new_component.editor.getStyle("regular"));
			doc.insertString(doc.getLength(), "ADD R1 R1 R32;\n", new_component.editor.getStyle("regular"));
			doc.insertString(doc.getLength(), "BLE R1 #10 label1;\n", new_component.editor.getStyle("regular"));
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(getProgramInputScrollPane(), ex, "Error", JOptionPane.ERROR_MESSAGE);
			System.out.println(ex);
		}
	}
	
	/**
	 * This function displays the program in the combo boxes
	 */
	public void display_default_program_combo(ProgramInputComponent new_component)
	{
		try
		{
			ArrayList instruction_component;
			instruction_component =(ArrayList)instructions.get(0); 
			((JComboBox)instruction_component.get(1)).setSelectedItem("MOV");
			((JTextField)instruction_component.get(2)).setText("R32");
			((JTextField)instruction_component.get(3)).setText("#2");
			((JTextField)instruction_component.get(4)).setText("");
			
			instruction_component =(ArrayList)instructions.get(1); 
			((JComboBox)instruction_component.get(1)).setSelectedItem("BEQ");
			((JTextField)instruction_component.get(2)).setText("R32");
			((JTextField)instruction_component.get(3)).setText("#2");
			((JTextField)instruction_component.get(4)).setText("instr3");
			
			instruction_component =(ArrayList)instructions.get(2); 
			((JComboBox)instruction_component.get(1)).setSelectedItem("MOV");
			((JTextField)instruction_component.get(2)).setText("R31");
			((JTextField)instruction_component.get(3)).setText("R32");
			((JTextField)instruction_component.get(4)).setText("");
			
			instruction_component =(ArrayList)instructions.get(3); 
			((JComboBox)instruction_component.get(1)).setSelectedItem("ADD");
			((JTextField)instruction_component.get(2)).setText("R1");
			((JTextField)instruction_component.get(3)).setText("R1");
			((JTextField)instruction_component.get(4)).setText("R32");
			
			instruction_component =(ArrayList)instructions.get(4); 
			((JComboBox)instruction_component.get(1)).setSelectedItem("BLE");
			((JTextField)instruction_component.get(2)).setText("R1");
			((JTextField)instruction_component.get(3)).setText("#10");
			((JTextField)instruction_component.get(4)).setText("instr2");
			
			instruction_component =(ArrayList)instructions.get(5); 
			((JComboBox)instruction_component.get(1)).setSelectedItem("END");
			((JTextField)instruction_component.get(2)).setText("");
			((JTextField)instruction_component.get(3)).setText("");
			((JTextField)instruction_component.get(4)).setText("");
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(getProgramInputScrollPane(), ex, "Error", JOptionPane.ERROR_MESSAGE);
			System.out.println(ex);
		}
	}
	
	public JPanel getBtbInputParametersPanel()
	{
		JLabel label_local_bits, label_global_bits, label_no_btb_entries;
		programInputPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
				
		c.gridx = 0;
		c.gridy = 0;
		c.insets = new Insets(10,10,10,10);
		label_local_bits = new JLabel("No. of local prediction bits: ");
		programInputPanel.add(label_local_bits, c);
		
		c.gridx = 2;
		c.gridy = 0;
		c.insets = new Insets(10,10,10,10);
		local_bits_combo = new JComboBox(new String[] {"1","2"});
		programInputPanel.add(local_bits_combo, c);
		
		c.gridx = 0;
		c.gridy = 1;
		c.insets = new Insets(10,10,10,10);
		label_global_bits = new JLabel("No. of Global prediction bits: ");
		programInputPanel.add(label_global_bits, c);
		
		c.gridx = 2;
		c.gridy = 1;
		c.insets = new Insets(10,10,10,10);
		global_bits_combo = new JComboBox(new String[] {"0","1","2","3","4"});
		programInputPanel.add(global_bits_combo, c);
		
		c.gridx = 0;
		c.gridy = 2;
		c.insets = new Insets(10,10,10,10);
		label_no_btb_entries = new JLabel("No. of entries in Branch Target Buffer:");
		programInputPanel.add(label_no_btb_entries, c);
		
		c.gridx = 2;
		c.gridy = 2;
		c.insets = new Insets(10,10,10,10);
		no_btb_entries_combo = new JComboBox(new String[] {"1","2","4","16","32","64"});
		programInputPanel.add(no_btb_entries_combo, c);
		
		c.gridx = 0;
		c.gridy = 3;
		c.insets = new Insets(10,10,10,10);
		JButton back_parameters = new JButton("Back");
		back_parameters.setActionCommand("Back_Parameters");
		back_parameters.addActionListener(this);
		back_parameters.setToolTipText("Click this button to go back to previous screen");
		programInputPanel.add(back_parameters, c);
		
		c.gridx = 2;
		c.gridy = 3;
		c.insets = new Insets(10,10,10,10);
		JButton go_parameters = new JButton("Go");
		go_parameters.setActionCommand("Go_Parameters");
		go_parameters.addActionListener(this);
		go_parameters.setToolTipText("Click this button to start running the program");
		programInputPanel.add(go_parameters, c);
		return programInputPanel;
	}
	
	public JPanel getEditorPanel()
	{
		programInputPanel = new JPanel();
		programInputPanel.setLayout(new BoxLayout(programInputPanel,BoxLayout.PAGE_AXIS));
		programInputPanel.add(Box.createRigidArea(new Dimension(0,15)));
		
		JLabel label_programInput=new JLabel("INPUT YOUR PROGRAM HERE");
		label_programInput.setFont(new Font("Serif", Font.BOLD, 14));
		label_programInput.setAlignmentX(Box.CENTER_ALIGNMENT);
		programInputPanel.add(label_programInput);
		programInputPanel.add(Box.createRigidArea(new Dimension(0,30)));
		
		//Display the Editor
		programInputEditorScrollPane = new JScrollPane(getProgramInputEditorPanel());
		programInputEditorScrollPane.setPreferredSize(new Dimension((int)(programInputComponentDim.getWidth()*5.0/8.0),(int)(programInputComponentDim.getHeight()*1.0/3.0)));
		JPanel editorPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx=0;
		c.gridy=0;
		double slack = (programInputPanel.getWidth() - programInputEditorScrollPane.getPreferredSize().getWidth());
		c.insets = new Insets(0,(int)(slack/2.0),0,(int)(slack/2.0));
		//c.insets = new Insets(0,20,0,20);
		editorPanel.add(programInputEditorScrollPane, c);
		programInputPanel.add(editorPanel);
		programInputPanel.add(Box.createRigidArea(new Dimension(0,15)));
		
		//Display the Editor Buttons Panel
		programInputEditorButtonsPanel = getEditorButtonsPanel();
		programInputPanel.add(programInputEditorButtonsPanel);
		programInputPanel.add(Box.createRigidArea(new Dimension(0,15)));
		
		//programInputPanel.setPreferredSize(programInputComponentDim);
		programInputPanel.setMinimumSize(programInputComponentMinDim);
		return programInputPanel;
	}
	
	public JPanel getEditorButtonsPanel()
	{
		JPanel buttonsPanel;
		double slack = (programInputPanel.getWidth() - programInputEditorScrollPane.getPreferredSize().getWidth());
		buttonsPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		back_button_editor = new JButton("Back");
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1;
		c.insets = new Insets(10,(int)(slack*3.0/8.0),10,(int)(slack*1.0/8.0));
		//c.insets = new Insets(10,15,10,15);
		back_button_editor.setActionCommand("Back_Editor");
		back_button_editor.addActionListener(this);
		back_button_editor.setToolTipText("Click this button to go back to previous screen");
		buttonsPanel.add(back_button_editor,c);
		
		go_button_editor = new JButton("Go");
		c.gridx = 4;
		c.gridy = 0;
		c.gridwidth = 2;
		c.insets = new Insets(10,(int)(slack*1.0/8.0),10,(int)(slack*3.0/8.0));
		//c.insets = new Insets(10,15,10,15);
		go_button_editor.setActionCommand("Go_Editor");
		go_button_editor.addActionListener(this);
		go_button_editor.setToolTipText("Click this button to go ahead and choose the Branch Target Buffer Parameters");
		buttonsPanel.add(go_button_editor,c);
		return buttonsPanel;
	}

	public void actionPerformed(ActionEvent e)
	{
		if("Back_Editor".equals(e.getActionCommand()))
		{
			try
			{
				ProgramInputComponent new_component = new ProgramInputComponent(mainFrame, 0, mainFrame.frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.horizontalSplitPane.setLeftComponent(new_component.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)mainFrame.frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
				
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(getProgramInputScrollPane(), ex, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(ex);
			}
		}
		else if("Go_Editor".equals(e.getActionCommand()))
		{
			//Disable the back button.
			//back_button_editor.setEnabled(false);
			String program=editor.getText();
			
			//Input the program
			try
			{
				mainFrame.alp = new AssemblyLanguageParser(program);
				
				//Display the Branch Target Buffer Input Parameters now
				ProgramInputComponent new_component = new ProgramInputComponent(mainFrame, 2, mainFrame.frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.horizontalSplitPane.setLeftComponent(new_component.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)mainFrame.frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(getProgramInputScrollPane(), ex, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(ex);
			}				
		}
		else if("Back_Parameters".equals(e.getActionCommand()))
		{
			
		}
		else if("Go_Parameters".equals(e.getActionCommand()))
		{
			try
			{
				//Input Parameters
				int no_local_bits = Integer.parseInt((String)local_bits_combo.getSelectedItem());
				int no_global_bits = Integer.parseInt((String)global_bits_combo.getSelectedItem());
				int no_btb_entries = Integer.parseInt((String)no_btb_entries_combo.getSelectedItem());
				//Intialize the predictor with these parameters
				mainFrame.pred = new predictor();
				mainFrame.pred.init(no_local_bits, no_global_bits, no_btb_entries);
				
				//Display the editor
				ProgramInputComponent new_component = new ProgramInputComponent(mainFrame, 1, mainFrame.frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.horizontalSplitPane.setLeftComponent(new_component.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)mainFrame.frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
				
				//Display the program inside the editor
				displayProgramInEditor(new_component);
												
				//Starting to run the program now
				mainFrame.alp.init_execution(mainFrame.pred);
				mainFrame.btbComponent.cycle_by_cycle.setEnabled(true);
				mainFrame.btbComponent.to_end.setEnabled(true);
				mainFrame.btbComponent.step_branch.setEnabled(true);
				mainFrame.btbComponent.reset.setEnabled(true);
				
				//Enabling the registers/statistics display panel
				mainFrame.registersDisplayComponent.submit.setEnabled(true);
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(getProgramInputScrollPane(), ex, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(ex);
			}
		}
		else if("Editor_Combos".equals(e.getActionCommand()))
		{
			try
			{
				ProgramInputComponent new_component = new ProgramInputComponent(mainFrame, 1, mainFrame.frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.horizontalSplitPane.setLeftComponent(new_component.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)mainFrame.frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
				
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(getProgramInputScrollPane(), ex, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(ex);
			}
		}
		else if("Go_Combos".equals(e.getActionCommand()))
		{
			//Input the program from combos
			String program=inputProgramCombos();
			
			//Input the program
			try
			{
				mainFrame.alp = new AssemblyLanguageParser(program);
				
				//Display the Branch Target Buffer Input Parameters now
				ProgramInputComponent new_component = new ProgramInputComponent(mainFrame, 2, mainFrame.frame_dimension, mainFrame.programInputComponentMinDim, mainFrame.programInputComponentDim);
				mainFrame.horizontalSplitPane.setLeftComponent(new_component.getProgramInputScrollPane());
				mainFrame.horizontalSplitPane.setOneTouchExpandable(true);
				mainFrame.horizontalSplitPane.setDividerLocation((int)(programInputComponentDim.getWidth()));
				mainFrame.horizontalSplitPane.setMinimumSize(new Dimension((int)mainFrame.frame_dimension.getWidth(),(int)(mainFrame.programInputComponentMinDim.getHeight())));
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(getProgramInputScrollPane(), ex, "Error", JOptionPane.ERROR_MESSAGE);
				System.out.println(ex);
			}
		}
	}
	
	/**
	 * Returns the Program Input Scroll Pane. The Scroll Pane 
	 * could have the combo boxes or the editor.
	 * @return
	 */
	public Component getProgramInputScrollPane()
	{
		return programInputScrollPane;
	}
	
	/**
	 * Builds the combo boxes in the program input panels.
	 * Saves the combo boxes in an arraylist.
	 */
	public void build_programInput_combos()
	{
		instructions = new ArrayList(NO_INSTRUCTIONS);
		for(int i=0;i<NO_INSTRUCTIONS;i++)
		{
			instruction_components = new ArrayList(5);
			JLabel instr_label = new JLabel("instr"+(i+1));
			instruction_components.add(instr_label);
			JComboBox instr = new JComboBox(instrs);
			instruction_components.add(instr);
			JTextField arg1 = new JTextField(5);
			instruction_components.add(arg1);
			JTextField arg2 = new JTextField(5);
			instruction_components.add(arg2);
			JTextField arg3 = new JTextField(5);
			instruction_components.add(arg3);
			instructions.add(instruction_components);
		}
	}
	
	/**
	 * Gets the Program Input Panel having the
	 * Editor
	 * @return editor
	 */
	public Component getProgramInputEditorPanel()
	{
		editor = new JTextPane();
		//Create the styles we need
		initStylesForEditorPane();
		return editor;
	}
	
	public void displayProgramInEditor(ProgramInputComponent new_component)
	{
		new_component.editor.setText("");
		Document doc = new_component.editor.getDocument();
		
		//Load the program into the editor
		try
		{
			for(int i=0; i<mainFrame.alp.instructions.size(); i++)
			{
				if(mainFrame.alp.labels.containsValue(new Integer(i)))
				{
					Set keys = mainFrame.alp.labels.keySet();
					//Display all the labels to this instruction
					Iterator it=keys.iterator();
					while(it.hasNext())
					{
						String key = (String)it.next();
						if(((Integer)mainFrame.alp.labels.get(key)).intValue()==i)
							doc.insertString(doc.getLength(), key+":\n", new_component.editor.getStyle("regular"));
					}						
				}
				if(i==mainFrame.alp.PC)
					doc.insertString(doc.getLength(), mainFrame.alp.instructions.get(i)+";\n", new_component.editor.getStyle("bold_red"));
				else
					doc.insertString(doc.getLength(), mainFrame.alp.instructions.get(i)+";\n", new_component.editor.getStyle("regulars"));
				new_component.back_button_editor.setEnabled(false);
				new_component.go_button_editor.setEnabled(false);
			}
			
			new_component.editor.setEditable(false);
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(getProgramInputScrollPane(), ex, "Error", JOptionPane.ERROR_MESSAGE);
			System.out.println(ex);
		}
	}
	
	public void initStylesForEditorPane()
	{
		//Initialize some styles
		Style def = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);
		
		Style regular = editor.addStyle("regular", def);
		StyleConstants.setFontFamily(def, "SansSerif");
		StyleConstants.setForeground(def, Color.BLACK);
		
		Style s = editor.addStyle("bold_red", regular);
		StyleConstants.setBold(s, true);
		StyleConstants.setForeground(s, Color.RED);
	}
	
	public String inputProgramCombos()
	{
		StringBuffer program=new StringBuffer("");
		for(int i=0;i<NO_INSTRUCTIONS;i++)
		{
			String str1 = ((JLabel)(((ArrayList)(instructions.get(i))).get(0))).getText();
			String str2 = (String)(((JComboBox)(((ArrayList)(instructions.get(i))).get(1))).getSelectedItem());
			String str3 = ((JTextField)(((ArrayList)(instructions.get(i))).get(2))).getText();
			String str4 = ((JTextField)(((ArrayList)(instructions.get(i))).get(3))).getText();
			String str5 = ((JTextField)(((ArrayList)(instructions.get(i))).get(4))).getText();
			
			program.append(new String(str1+": "+str2+" "+str3+" "+str4+" "+str5+";"));
			if(str2.equals("END"))
				break;
		}
		return new String(program);
	}
	
	/**
	 * Gets the Program Input Panel having combo boxes.
	 * @return programInputPanel
	 */
	public JPanel getProgramInputCombosPanel()
	{
		programInputPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		JLabel label_top_left=new JLabel("INPUT YOUR PROGRAM HERE");
		label_top_left.setFont(new Font("Serif", Font.BOLD, 14));
		c.gridy = 0;
		c.gridx = 1;
		c.gridwidth=3;
		c.insets = new Insets(25,0,25,0);
		programInputPanel.add(label_top_left,c);
		
		for(int i=0;i<NO_INSTRUCTIONS;i++)
		{
			c.gridy=i+2;
			for(int j=0;j<5;j++)
			{
				c.gridx=j;
				c.gridwidth=1;
				c.insets = new Insets(3,3,3,3);
				programInputPanel.add((Component)(((ArrayList)(instructions.get(i))).get(j)),c);
			}
		}
		//Display the editor option button
		editor_button_combos = new JButton("Editor");
		c.gridx=1;
		c.gridy=NO_INSTRUCTIONS+2;
		c.gridwidth = 2;
		c.insets = new Insets(15,0,15,0);
		editor_button_combos.addActionListener(this);
		editor_button_combos.setActionCommand("Editor_Combos");
		editor_button_combos.setToolTipText("Click to go to the Editor");
		programInputPanel.add(editor_button_combos,c);
		
		//Display the Go option button
		go_button_combos = new JButton("Go");
		c.gridx = 3;
		c.gridy = NO_INSTRUCTIONS+2;
		c.gridwidth = 2;
		c.insets = new Insets(15,0,15,0);
		go_button_combos.addActionListener(this);
		go_button_combos.setActionCommand("Go_Combos");
		go_button_combos.setToolTipText("Click to run the entered program");
		programInputPanel.add(go_button_combos,c);
		return programInputPanel;
	}
}
