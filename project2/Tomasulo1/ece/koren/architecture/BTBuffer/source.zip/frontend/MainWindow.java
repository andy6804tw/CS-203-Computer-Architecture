/*
 * Created on Jan 5, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package frontend;
import javax.swing.*;
import java.awt.*;
//import exception_classes.*;

/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class MainWindow extends JApplet
{
	Container applet_panel;
	public static MainWindow frame;
	Dimension dim;
	
	public MainWindow()
	{
		//init_backend();
		init_frontend();		
	}
	
	public void init_frontend()
	{
		try
		{
			dim = new Dimension(1000, 700);
			setSize(dim);
			applet_panel=getContentPane();
			applet_panel.setLayout(new BoxLayout(applet_panel,BoxLayout.Y_AXIS));
			
			JPanel heading_panel = new JPanel();
			heading_panel.setBackground(Color.BLACK);
			JLabel heading = new JLabel("COMBINED BRANCH PREDICTOR/BRANCH TARGET BUFFER");
			heading.setFont(new Font("Serif",Font.BOLD,18));
			heading.setForeground(Color.YELLOW);
			heading.setAlignmentX(Box.CENTER_ALIGNMENT);
			heading_panel.add(heading);
			applet_panel.add(heading_panel);
			
			Dimension new_dim = new Dimension((int)dim.getWidth() , (int)(dim.getHeight() - heading_panel.getHeight()));
			
			splitMainFrame splitFrame= new splitMainFrame(new_dim);
			JComponent my_frame = splitFrame.getSplitPane();
			my_frame.setAlignmentX(Box.CENTER_ALIGNMENT);
			applet_panel.add(splitFrame.getSplitPane());			
		}
		catch(Exception e)
		{
			System.err.println("createGUI didnt successfully complete");
		}
	}
		
	public static void main (String args[])
	{
		frame = new MainWindow();
		frame.setVisible(true);
	}
}
