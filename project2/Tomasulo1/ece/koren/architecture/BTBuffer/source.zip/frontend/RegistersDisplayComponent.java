/*
 * Created on Jan 14, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package frontend;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import backend.*;

/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RegistersDisplayComponent implements ActionListener
{
	JPanel registersPanel;
	JLabel label_bottom;
	public boolean parameters_taken;
	
	splitMainFrame mainFrame;
	
	Dimension registersDisplayComponentMinDim, registersDisplayComponentDim;
	
	JList list_registers;
	JCheckBox no_hits, no_misses, miss_ratio, correct_predictions, incorrect_predictions, misprediction_ratio, total_instructions, branch_instructions, percentage_branch_instructions;
	public JButton submit;
	public RegistersDisplayComponent(RegistersDisplayComponent old_component, splitMainFrame mf, int index, Dimension frame_dimension, Dimension minDim, Dimension dim)
	{
		mainFrame = mf;
		
		registersDisplayComponentMinDim = minDim;
		registersDisplayComponentDim = dim;
		
		
		if(index==0)	//Display the choosing panel
		{
			parameters_taken = false;
			registersPanel = new JPanel();
			registersPanel.setLayout(new BoxLayout(registersPanel, BoxLayout.PAGE_AXIS));
			registersPanel.setMinimumSize(registersDisplayComponentMinDim);
			
			double width = registersDisplayComponentDim.getWidth();
			double height = registersDisplayComponentDim.getHeight();
			label_bottom = new JLabel("CHOOSE YOUR DISPLAY");
			label_bottom.setFont(new Font("Serif", Font.BOLD, 14));
			label_bottom.setForeground(Color.BLACK);
			label_bottom.setAlignmentX(Box.CENTER_ALIGNMENT);
			registersPanel.add(label_bottom);
			registersPanel.add(Box.createRigidArea(new Dimension(0,(int)(height*1.0/16.0))));
			
			JPanel output_sub_panel = new JPanel(new GridBagLayout());
			GridBagConstraints c = new GridBagConstraints();
			
			//Show Registers Display option
			JLabel registers_label = new JLabel("Choose Registers for Display");
			registers_label.setFont(new Font("Serif",Font.BOLD, 14));
			c.gridx=0;
			c.gridy=0;
			c.insets=new Insets(10,10,10,10);
			output_sub_panel.add(registers_label, c);
			
			String str[] = {"All Registers","R1","R2","R3","R4","R5","R6","R7","R8",
					"R9","R10","R11","R12","R13","R14","R15","R16",
					"R17","R18","R19","R20","R21","R22","R23","R24",
					"R25","R26","R27","R28","R29","R30","R31","R32"};
			list_registers = new JList(str);
			list_registers.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			list_registers.setLayoutOrientation(JList.VERTICAL);
			list_registers.setVisibleRowCount(-1);
			JScrollPane list_scrollPane = new JScrollPane(list_registers);
			list_scrollPane.setPreferredSize(new Dimension((int)(width/16.0),(int)(height*3.0/4.0)));
			c.gridx = 0;
			c.gridy = 1;
			c.gridheight = 3;
			c.insets = new Insets(10,10,10,10);
			output_sub_panel.add(list_scrollPane,c);		
			
			//Show statistics display option
			JLabel statistics_label = new JLabel("Choose which Statistics to Display at the end");
			statistics_label.setFont(new Font("Serif",Font.BOLD, 14));
			c.gridx=2;
			c.gridy=0;
			c.gridheight=1;
			//c.gridwidth=2;
			c.insets=new Insets(10,10,10,10);
			output_sub_panel.add(statistics_label, c);
			
			no_hits = new JCheckBox("No. of hits");
			c.gridx = 1;
			c.gridy = 1;
			c.insets = new Insets(10,10,10,10);
			no_hits.setSelected(true);
			output_sub_panel.add(no_hits, c);
						
			no_misses = new JCheckBox("No. of misses");
			c.gridx = 1;
			c.gridy = 2;
			c.insets = new Insets(10,10,10,10);
			no_misses.setSelected(true);
			output_sub_panel.add(no_misses, c);
			
			miss_ratio = new JCheckBox("Miss Ratio");
			c.gridx = 1;
			c.gridy = 3;
			c.insets = new Insets(10,10,10,10);
			miss_ratio.setSelected(true);
			output_sub_panel.add(miss_ratio, c);
			
			correct_predictions = new JCheckBox("No. of correct predictions");
			c.gridx = 2;
			c.gridy = 1;
			c.insets = new Insets(10,10,10,10);
			correct_predictions.setSelected(true);
			output_sub_panel.add(correct_predictions, c);
			
			incorrect_predictions = new JCheckBox("No. of incorrect predictions");
			c.gridx = 2;
			c.gridy = 2;
			c.insets = new Insets(10,10,10,10);
			incorrect_predictions.setSelected(true);
			output_sub_panel.add(incorrect_predictions, c);
			
			misprediction_ratio = new JCheckBox("Misprediction Ratio");
			c.gridx = 2;
			c.gridy = 3;
			c.insets = new Insets(10,10,10,10);
			misprediction_ratio.setSelected(true);
			output_sub_panel.add(misprediction_ratio, c);
			
			total_instructions = new JCheckBox("Total No. of Instructions");
			c.gridx = 3;
			c.gridy = 1;
			c.insets = new Insets(10,10,10,10);
			output_sub_panel.add(total_instructions, c);
			
			branch_instructions = new JCheckBox("No. of Branch Instructions");
			c.gridx = 3;
			c.gridy = 2;
			c.insets = new Insets(10,10,10,10);
			output_sub_panel.add(branch_instructions, c);
			
			percentage_branch_instructions = new JCheckBox("Percentage of Branch Instructions");
			c.gridx = 3;
			c.gridy = 3;
			c.insets = new Insets(10,10,10,10);
			output_sub_panel.add(percentage_branch_instructions, c);
			
			submit = new JButton("Submit");
			c.gridx = 2;
			c.gridy = 4;
			c.gridwidth = 2;
			submit.setActionCommand("submit_button");
			submit.addActionListener(this);
			submit.setEnabled(false);
			submit.setToolTipText("Click this button to show the selected choices");
			output_sub_panel.add(submit, c);
			
			registersPanel.add(output_sub_panel);
			//registersPanel.setEnabled(false);
		}
		else if(index==1)//Display the registers
		{
			//Copying old values into the new component
			parameters_taken = old_component.parameters_taken;
			list_registers = old_component.list_registers;
			no_hits = old_component.no_hits;
			no_misses = old_component.no_misses;
			miss_ratio = old_component.miss_ratio;
			correct_predictions = old_component.correct_predictions;
			incorrect_predictions = old_component.incorrect_predictions;
			misprediction_ratio = old_component.misprediction_ratio;
			total_instructions = old_component.total_instructions; 
			branch_instructions = old_component.branch_instructions;
			percentage_branch_instructions = old_component.percentage_branch_instructions;
			
			registersPanel = new JPanel(new GridBagLayout());
			registersPanel.setMinimumSize(registersDisplayComponentMinDim);
			
			GridBagConstraints c = new GridBagConstraints();
			//Show Registers Display option
			if((list_registers.getSelectedValues()).length > 0)
			{
				JLabel registers_label = new JLabel("Registers");
				registers_label.setFont(new Font("Serif",Font.BOLD, 18));
				c.gridx=0;
				c.gridy=0;
				c.insets=new Insets(10,10,10,10);
				registersPanel.add(registers_label, c);
				//Display the chosen registers
				for(int i=1;i<33;i++)
				{
					String str = new String("R"+i);
					Object []str_array = list_registers.getSelectedValues();
				
					boolean display = false;
					for(int j=0;j<str_array.length; j++)
					{
						if(str.equals(str_array[j]) || "All Registers".equals(str_array[j]))
						{
							display = true;
							break;
						}
					}
					//Display this register if it is selected
					if(display == true)
					{
						c.gridx = 0;
						c.gridy++;
						JLabel register_label = new JLabel("R"+i+": ");
						registersPanel.add(register_label,c);
						c.gridx = 1;
						String register_value_string = mainFrame.alp.registers.get(i-1)+"";
						JLabel register_value = new JLabel(register_value_string);
						registersPanel.add(register_value,c);
					}
				}
				c.gridx = 2;
				c.gridy = 0;
				c.insets=new Insets(10,10,10,10);
			}
			else
			{
				c.gridx = 0;
				c.gridy = 0;
				c.insets=new Insets(10,10,10,10);
			}
			//Display statistic values if program has completed			
			if(AssemblyLanguageParser.program_ends || mainFrame.alp.PC >= mainFrame.alp.instructions.size())
			{
				//Display the chosen statistics
				if(no_hits.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("No. of hits: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					String statistic_value_string = mainFrame.pred.hits + "";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value, c);
					c.gridx--;
				}				
				if(no_misses.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("No. of Misses: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					String statistic_value_string = mainFrame.pred.misses + "";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value,c);
					c.gridx--;
				}
				if(miss_ratio.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("Miss Ratio: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					double value = ((double)(mainFrame.pred.misses)/(double)(mainFrame.pred.misses + mainFrame.pred.hits));
					value = (double)((int)(value * 100.0))/100.0;
					String statistic_value_string = value + "";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value,c);
					c.gridx--;
				}
				if(correct_predictions.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("Correct Predictions: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					String statistic_value_string = (mainFrame.pred.total_predictions - mainFrame.pred.mispredictions)+"";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value,c);
					c.gridx--;
				}
				if(incorrect_predictions.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("Incorrect Predictions: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					String statistic_value_string = mainFrame.pred.mispredictions+"";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value,c);
					c.gridx--;
				}
				if(misprediction_ratio.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("MisPrediction Ratio: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					double value = ((double)mainFrame.pred.mispredictions/(double)mainFrame.pred.total_predictions);
					value = (double)((int)(value * 100.0))/100.0;
					String statistic_value_string = value +"";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value,c);
					c.gridx--;
				}
				if(total_instructions.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("Total No. of Instructions Executed: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					String statistic_value_string = mainFrame.alp.total_instructions + "";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value,c);
					c.gridx--;
				}
				if(branch_instructions.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("No. of Branch Instructions Executed: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					String statistic_value_string = mainFrame.alp.branch_instructions + "";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value,c);
					c.gridx--;
				}
				if(percentage_branch_instructions.isSelected())
				{
					c.gridy++;
					c.gridx = c.gridx + ((c.gridy - 1)/3)*2;
					c.gridy = (c.gridy - 1)%3 + 1;
					JLabel statistic_label = new JLabel("Percentage of Branch Instructions: ");
					registersPanel.add(statistic_label, c);
					c.gridx++;
					double value = ((double)(mainFrame.alp.branch_instructions)/(double)(mainFrame.alp.total_instructions));
					value = (double)((int)(value * 100.0))/100.0;
					String statistic_value_string = value +"";
					JLabel statistic_value = new JLabel(statistic_value_string);
					registersPanel.add(statistic_value,c);
					c.gridx--;
				}
				
				//Display Heading -- "Statistics"
				JLabel statistics_label = new JLabel("Statistics");
				statistics_label.setFont(new Font("Serif",Font.BOLD, 18));
				
				c.gridx=((c.gridx + 1) - 2)/2 + 2;
				c.gridy=0;
				c.insets=new Insets(10,10,10,10);
				registersPanel.add(statistics_label, c);				
			}
		}
	}
	
	public void actionPerformed (ActionEvent evt)
	{
		if("submit_button".equals(evt.getActionCommand()))
		{
			parameters_taken = true;
			RegistersDisplayComponent new_component=new RegistersDisplayComponent(this, mainFrame, 1, mainFrame.frame_dimension, registersDisplayComponentMinDim, registersDisplayComponentDim);
			mainFrame.verticalSplitPane.setBottomComponent(new_component.getRegisterDisplayPanel());
			mainFrame.verticalSplitPane.setOneTouchExpandable(true);
			//mainFrame.verticalSplitPane.setDividerLocation(mainFrame.frame_dimension.getHeight()-registersDisplayComponentDim.getHeight());
			//mainFrame.verticalSplitPane.setPreferredSize(mainFrame.frame_dimension);
		
		}
	}
	
	public Component getRegisterDisplayPanel()
	{
		JScrollPane registersScrollPane = new JScrollPane(registersPanel);
		registersScrollPane.setMinimumSize(registersDisplayComponentMinDim);
		registersScrollPane.setPreferredSize(registersDisplayComponentDim);
		return registersScrollPane;		
	}
}
