/*
 * Created on Dec 29, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package exception_classes;

/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class InvalidProgramException extends Exception 
{
	String str;
	
	public InvalidProgramException(String str1)
	{
		str = new String(str1);
	}
	
	public String toString()
	{
		return str;
	}
}
