/*
 * Created on Dec 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package exception_classes;

/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UnidentifiedInstructionException extends Exception 
{
	String str;
	
	public UnidentifiedInstructionException(String instr, int instr_no)
	{
		str = new String("Unidentified Instruction:\n"+instr+"\nInstruction No.: "+(instr_no+1));
	}
	
	public String toString()
	{
		return str;
	}
}
