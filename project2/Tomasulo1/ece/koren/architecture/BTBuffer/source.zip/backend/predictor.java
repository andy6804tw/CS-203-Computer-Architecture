/*
 * Created on Dec 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package backend;
import exception_classes.*;
import java.util.*;

/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class predictor 
{
	public ArrayList global_bht;
	public ArrayList btb;	//Branch Target Buffer
	int no_local_bits;
	public int no_global_bits;
	int no_buffer_entries;
	public int total_predictions;
	public int mispredictions;
	public int hits, misses;
	
	public void init(int n, int m, int N)
	{
		no_local_bits=n;
		no_global_bits=m;
		no_buffer_entries=N;
		total_predictions=0;
		mispredictions=0;
		hits=0;
		misses=0;
		btb = new ArrayList();
		for(int i=0;i<N;i++)
		{
			int []btb_entry = new int[2];
			btb_entry[0]=-1;	//Tag Number
			btb_entry[1]=-1;	//Predicted Address
			btb.add(btb_entry);			
		}
		global_bht = new ArrayList();
		for(int i=0;i<(int)Math.pow(2.0,(double)m);i++)
		{
			ArrayList local_bht=new ArrayList(N);
			for(int j=0;j<N;j++)
				local_bht.add(new Integer(0));
			global_bht.add(local_bht);
		}		
	}
	
	void prediction_table(int branch_address, int next_address, int branch_taken_address, String global_history) throws InvalidPredictionException
	{
		int next_bits;
		int index, bht_no;
		index=branch_address%no_buffer_entries;
		bht_no=get_local_bht_no(global_history);
		/**
		 * Find the prediction state for this branch
		 */
		ArrayList global_bht_this=(ArrayList) global_bht.get(bht_no);
		total_predictions++;
		
		/**
		 * Check if entry exists in Branch Target Buffer
		 */
		if(!(((int[])(btb.get(index)))[0]==branch_address))
		{
			System.out.println("Entry not found in BTB");
			misses++;
			//Entry doesnt exist in Branch Target Buffer
			//Set the tag
			((int[])btb.get(index))[0]=branch_address;
			if(no_local_bits==1)
			{
				if(next_address==branch_address+1)
				{
					//Branch not taken
					((int[])(btb.get(index)))[1]=branch_address+1;
					if(AssemblyLanguageParser.branch_taken)
					{
						global_bht_this.set(index, new Integer(0));
						mispredictions++;
					}
					else
						global_bht_this.set(index, new Integer(0));
				}
				else
				{
					//Branch taken
					((int[])(btb.get(index)))[1]=branch_taken_address;
					if(!AssemblyLanguageParser.branch_taken)
					{
						global_bht_this.set(index, new Integer(3));
						mispredictions++;
					}
					else
						global_bht_this.set(index, new Integer(3));
				}
			}
			else if(no_local_bits==2)
			{
				if(next_address==branch_address+1)
				{
					//Branch not taken
					if(AssemblyLanguageParser.branch_taken)
					{
						((int[])(btb.get(index)))[1]=branch_taken_address;
						global_bht_this.set(index, new Integer(2));// Go to T*N
						mispredictions++;
					}
					else
					{
						((int[])(btb.get(index)))[1]=branch_address+1;
						global_bht_this.set(index, new Integer(0));//Reset to N*
					}
				}
				else
				{
					//Branch taken
					if(!AssemblyLanguageParser.branch_taken)
					{
						((int[])(btb.get(index)))[1]=branch_address+1;
						global_bht_this.set(index, new Integer(1));// Go to N*T
						mispredictions++;
					}
					else
					{
						((int[])(btb.get(index)))[1]=branch_taken_address;
						global_bht_this.set(index, new Integer(3));//Go to T*
					}
				}
			}
			else
			{
				throw new InvalidPredictionException("Invalid number of local bits for branch history table. "+ no_local_bits);
			}
			return;
		}
		
		//Comes here when there is entry in the branch target buffer.
		System.out.println("Entry found in BTB");
		hits++;
		switch(((Integer)global_bht_this.get(index)).intValue())
		{
		case 0:	//N*
			if(no_local_bits==1)
			{
				if(next_address==branch_address+1)
				{
					//Branch not taken					
				}
				else
				{
					//Branch taken
					((int[])(btb.get(index)))[1]=branch_taken_address;
					global_bht_this.set(index, new Integer(3));
					mispredictions++;
				}
			}
			else if(no_local_bits==2)
			{
				if(next_address==branch_address+1)
				{
					//Branch not taken
					
				}
				else
				{
					//Branch taken -- but still predict non-taken
					global_bht_this.set(index, new Integer(1));// Go to N*T
					mispredictions++;
				}
			}
			else
				throw new InvalidPredictionException("Invalid number of local bits for branch history table: State 00 " + no_local_bits);
			break;
		case 3://T*
			if(no_local_bits==1)
			{
				if(next_address==branch_address+1)
				{
					//Branch not taken
					((int[])(btb.get(index)))[1]=branch_taken_address;
					global_bht_this.set(index, new Integer(0));
					mispredictions++;
				}
				else
				{
					//Branch taken
				}
			}
			else if(no_local_bits==2)
			{
				if(next_address==branch_address+1)
				{
					//Branch not taken--but still predict taken
					global_bht_this.set(index, new Integer(2)); //Go to T*N
					mispredictions++;
				}
				else
				{
					//Branch taken
				}
			}
			else
				throw new InvalidPredictionException("Invalid number of local bits for branch history table: State 11 " + no_local_bits);
			break;			
		case 2://T*N
			if(no_local_bits==2)
			{
				if(next_address==branch_address+1)
				{
					//Branch not taken -- and start predicting taken
					((int[])(btb.get(index)))[1]=branch_taken_address;
					global_bht_this.set(index, new Integer(1)); //Go to N*T
					mispredictions++;
				}
				else
				{
					//Branch taken -- continue predicting taken
					global_bht_this.set(index, new Integer(3)); //Go to T*
				}
			}
			else
				throw new InvalidPredictionException("Invalid number of local bits for branch history table: State 10 " + no_local_bits);
			break;			
		case 1://N*T
			if(no_local_bits==2)
			{
				if(next_address==branch_address+1)
				{
					//Branch not taken -- continue predicting not taken
					global_bht_this.set(index, new Integer(0)); //Go to N*
				}
				else
				{
					//Branch taken -- and start predicting taken
					((int[])(btb.get(index)))[1]=branch_taken_address;
					global_bht_this.set(index, new Integer(2)); //Go to T*N
					mispredictions++;
				}
			}
			else
				throw new InvalidPredictionException("Invalid number of local bits for branch history table: State 01 " + no_local_bits);
			break;			
		}
	}
	public int get_local_bht_no(String global_history)
	{
		if(no_global_bits==0)
			return 0;
		else
		{
			global_history="0000".substring(no_global_bits)+global_history.substring(4-no_global_bits);
			return (Integer.valueOf(global_history,2)).intValue();
		}
	}
	void showBTB(String global_history)
	{
		//System.out.println("Global History "+global_history);
		for(int i=0;i<no_buffer_entries;i++)
		{
			System.out.print(((int[])btb.get(i))[0]+" "+((int [])btb.get(i))[1]+" ");
			for(int j=0;j<Math.pow(2.0, (double)no_global_bits);j++)
				System.out.print(((Integer)(((ArrayList)(global_bht.get(j))).get(i))).intValue()+" ");
			System.out.println("");
		}
		System.out.println("");
	}
	
}
