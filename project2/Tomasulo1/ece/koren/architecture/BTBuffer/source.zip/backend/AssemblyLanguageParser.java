/*
 * Created on Dec 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package backend; 
import exception_classes.*;
import java.util.*;
import java.util.regex.*;

/**
 * @author Sugam Pandey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class AssemblyLanguageParser 
{
	public static final int INVALID = -1;
	public static final int MOV_reg = 0;
	public static final int MOV_immediate = 1;
	public static final int ADD_reg = 2;
	public static final int ADD_immediate = 3;
	public static final int SUB_reg = 4;
	public static final int SUB_immediate = 5;
	public static final int MULT_reg = 6;
	public static final int MULT_immediate = 7;
	public static final int DIV_reg = 8;
	public static final int DIV_immediate = 9;
	public static final int MOD_reg = 10;
	public static final int MOD_immediate = 11;
	public static final int BEQ_reg = 12;
	public static final int BEQ_immediate = 13;
	public static final int BNE_reg = 14;
	public static final int BNE_immediate = 15;
	public static final int BLE_reg=16;
	public static final int BLE_immediate=17;
	public static final int BGE_reg=18;
	public static final int BGE_immediate=19;
	public static final int BLT_reg=20;
	public static final int BLT_immediate=21;
	public static final int BGT_reg=22;
	public static final int BGT_immediate=23;
	public static final int END = 24;
	public static final boolean branch_taken=false;
	public static boolean program_ends=false;
	
	public ArrayList instructions = new ArrayList(0);
	public ArrayList registers = new ArrayList(32);
	
	int reg1, reg2, reg3, immediate, label;
	public int PC; //Program Counter
	predictor pred;
	public String global_history;
	public String last_global_history;
	
	public Map labels = new HashMap(); //Mapping for label to the PC
	
	public int total_instructions, branch_instructions;
	
	public AssemblyLanguageParser(String program) throws DuplicateLabelException, InvalidInstructionFormatException, InvalidProgramException
	{
		/**
		 * Parses the program and stores the instructions
		 * in the arraylist. Also puts addresses in branch
		 * instructions instead of labels.
		 */
		Pattern p1 = Pattern.compile("\\s*;+[\\s;]*");
		
		if(!instructions.addAll(Arrays.asList(p1.split(program))))
			throw new InvalidProgramException("Couldnot Parse the program");
		
		//Should Check here if last instruction ends in ';'
		
		/*
		instructions.add("     MOV R32 #2");
		//instructions.add("label1: BEQ R32 #2 label");
		instructions.add("label: MOV R31 R32");
		instructions.add("    ADD   R1     R1     R32");
		instructions.add("BLE R1 #105 label");
		*/
		for(int i=0;i<instructions.size();i++)
		{
			String instr = (String)instructions.get(i);
			if(!instr.contains(":"))
				continue;
			
			/**
			 * There is a label. Valid Label formats are
			 * label: instr; 
			 * label1: label2: instr;
			 */
			Pattern p = Pattern.compile("\\s*:\\s*");
			
			//Break the instruction to see its components.
			ArrayList l = new ArrayList(Arrays.asList(p.split(instr)));
			/**
			 * Invalidate the instructions of the form 
			 * ":label: instr" , "label:: instr", label:
			 */
			for(int j=0;j<l.size();j++)
				if(((String)(l.get(j))).equals(""))
					throw new InvalidInstructionFormatException(instr,i);
			if(l.size()==1)
				throw new InvalidInstructionFormatException(instr,i);
			if(Pattern.matches(".*:\\s*",instr))
				throw new InvalidInstructionFormatException(instr,i);
			/**
			 * Get the value of the label. Note that the last
			 * entry in the arraylist l should be an instruction.
			 * Entries previous to the last have to be labels. 
			 */
			for(int j=0;j<l.size();j++)
			{
				if(j==l.size()-1)
				{
					//This entry should be an instruction
					instructions.set(i,l.get(j));
				}
				else
				{
					//Remove spaces from each label if any.
					Pattern p2 = Pattern.compile("\\s+");
					ArrayList l_sub = new ArrayList(Arrays.asList(p2.split((String)l.get(j))));
					l_sub=pruneEmptyWords(l_sub);
					if(l_sub.size()!=1) //Invalid Label
						throw new InvalidInstructionFormatException(instr,i);
					//Insert the label into the mapping
					if(!labels.containsKey(l_sub.get(0)))
						labels.put(l_sub.get(0),new Integer(i));
					else
						throw new DuplicateLabelException(instr,i);
				}				
			}			
		}
	}
	
	public void init_execution(predictor pred_temp)
	{
		/**
		 * Initializes system parameters
		 */
		for(int i=0; i<32; i++)
			registers.add(new Integer(0));
		pred=pred_temp;
		if(branch_taken)
		{
			global_history=new String("1111");
			last_global_history=new String("1111");
		}
		else
		{
			global_history=new String("0000");
			last_global_history=new String("0000");
		}
		PC=0;
		total_instructions=0;
		branch_instructions=0;
	}
	
	public void executeInstructions(int step_arg) throws InvalidInstructionFormatException, UnidentifiedInstructionException, InvalidPredictionException, InvalidProgramException
	{
		/**
		 * Executes the instructions stored in the arraylist.
		 */
		
		if(step_arg == 0 && PC<instructions.size() && !program_ends)
		{
			//Step instruction
			executeInstruction(PC);
		}
		else if(step_arg == 1 && PC<instructions.size() && !program_ends)
		{
			//Step branch
			int type;
			
			executeInstruction(PC);
			if(PC<instructions.size() && !program_ends)
				type = instructionType(PC);
			else
				type =-1;
			
			while(PC<instructions.size() && !program_ends && !(type == BEQ_reg || type == BEQ_immediate || type == BNE_reg || type == BNE_immediate || type == BLT_reg || type == BLT_immediate || type == BGT_reg || type == BGT_immediate || type == BLE_reg || type == BLE_immediate || type == BGE_reg || type == BGE_immediate))
			{
				executeInstruction(PC);
				type = instructionType(PC);
			}			
		}
		else if(step_arg == 2)
		{
			for(;PC<instructions.size() && !program_ends;)
			{
				executeInstruction(PC);
				//pred.showBTB(global_history);
			}
		}
		else
			System.out.println("Program run to completion!");
		//System.out.println(pred.mispredictions+" "+pred.total_predictions);
		//System.out.println(((double)pred.mispredictions/(double)pred.total_predictions));
		//System.out.println("done");
	}
	
	public void executeInstruction(int instr_no) throws InvalidInstructionFormatException, UnidentifiedInstructionException, InvalidPredictionException
	{
		String instruction = (String) instructions.get(instr_no);
		total_instructions++;
		int type = instructionType(instr_no);
		if(type == INVALID)
			throw new UnidentifiedInstructionException(instruction, instr_no);
		if(type == MOV_reg)
		{
			registers.set(reg1-1,registers.get(reg2-1));
			PC++;
		}
		if(type == MOV_immediate)
		{
			registers.set(reg1-1,new Integer(immediate));
			PC++;
		}
		if(type == ADD_reg)
		{
			int sum=((Integer)(registers.get(reg2-1))).intValue()+((Integer)(registers.get(reg3-1))).intValue();
			registers.set(reg1-1,new Integer(sum));
			PC++;
		}
		if(type == ADD_immediate)
		{
			int sum=((Integer)(registers.get(reg2-1))).intValue() + immediate;
			registers.set(reg1-1,new Integer(sum));
			PC++;
		}
		if(type == SUB_reg)
		{
			int diff=((Integer)(registers.get(reg2-1))).intValue()-((Integer)(registers.get(reg3-1))).intValue();
			registers.set(reg1-1,new Integer(diff));
			PC++;
		}
		if(type == SUB_immediate)
		{
			int diff=((Integer)(registers.get(reg2-1))).intValue() - immediate;
			registers.set(reg1-1,new Integer(diff));
			PC++;
		}
		if(type == MULT_reg)
		{
			int mult=((Integer)(registers.get(reg2-1))).intValue()*((Integer)(registers.get(reg3-1))).intValue();
			registers.set(reg1-1,new Integer(mult));
			PC++;
		}
		if(type == MULT_immediate)
		{
			int mult=((Integer)(registers.get(reg2-1))).intValue() * immediate;
			registers.set(reg1-1,new Integer(mult));
			PC++;
		}
		if(type == DIV_reg)
		{
			int div=((Integer)(registers.get(reg2-1))).intValue()/((Integer)(registers.get(reg3-1))).intValue();
			registers.set(reg1-1,new Integer(div));
			PC++;
		}
		if(type == DIV_immediate)
		{
			int div=((Integer)(registers.get(reg2-1))).intValue() / immediate;
			registers.set(reg1-1,new Integer(div));
			PC++;
		}
		if(type == MOD_reg)
		{
			int mod=((Integer)(registers.get(reg2-1))).intValue()%((Integer)(registers.get(reg3-1))).intValue();
			registers.set(reg1-1,new Integer(mod));
			PC++;
		}	
		if(type == MOD_immediate)
		{
			int mod=((Integer)(registers.get(reg2-1))).intValue() % immediate;
			registers.set(reg1-1,new Integer(mod));
			PC++;
		}
		if(type == BEQ_reg)
		{
			branch_instructions++;
			int last_address = PC;
			if(((Integer)(registers.get(reg1-1))).intValue() == ((Integer)(registers.get(reg2-1))).intValue())
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");				
		}
		if(type == BEQ_immediate)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() == immediate)
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");			
		}
		if(type == BNE_reg)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() != ((Integer)(registers.get(reg2-1))).intValue())
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == BNE_immediate)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() != immediate)
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == BLT_reg)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() < ((Integer)(registers.get(reg2-1))).intValue())
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == BLT_immediate)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() < immediate)
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == BGT_reg)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() > ((Integer)(registers.get(reg2-1))).intValue())
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == BGT_immediate)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() > immediate)
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == BLE_reg)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() <= ((Integer)(registers.get(reg2-1))).intValue())
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == BLE_immediate)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() <= immediate)
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");				
		}
		if(type == BGE_reg)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() >= ((Integer)(registers.get(reg2-1))).intValue())
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == BGE_immediate)
		{
			branch_instructions++;
			int last_address=PC;
			if(((Integer)(registers.get(reg1-1))).intValue() >= immediate)
				PC=label;
			else
				PC++;
			pred.prediction_table(last_address, PC, label, global_history);
			
			last_global_history=global_history;
			if(PC==last_address+1)
				global_history=new String(global_history.substring(1)+"0");
			else
				global_history=new String(global_history.substring(1)+"1");
		}
		if(type == END)
		{
			program_ends=true;
			PC++;
		}
	}
	
	public int instructionType(int instr_no) throws InvalidInstructionFormatException
	{
		String instr = (String)instructions.get(instr_no);
		Pattern p = Pattern.compile("\\s+");
		
		//Break the instruction to see its components.
		ArrayList l=new ArrayList(Arrays.asList(p.split(instr)));
		l=pruneEmptyWords(l);
		
		if(((String)l.get(0)).equals("MOV"))
		{
			if(l.size()!=3)
				throw new InvalidInstructionFormatException(instr, instr_no);
							
			if(!Pattern.matches("R[1-9]",((String)l.get(1))) && !Pattern.matches("R[1-2]\\d?",((String)l.get(1))) && !Pattern.matches("R3[0-2]",((String)l.get(1))))
				throw new InvalidInstructionFormatException(instr, instr_no);			
											
			if(!Pattern.matches("R[1-9]",((String)l.get(2))) && !Pattern.matches("R[1-2]\\d?",((String)l.get(2))) && !Pattern.matches("R3[0-2]",((String)l.get(2))) && !Pattern.matches("#[0-9]+",((String)l.get(2))))
				throw new InvalidInstructionFormatException(instr, instr_no);			
										
			reg1=Integer.parseInt(((String)l.get(1)).substring(1));
			
			//System.out.println(l.size()+" "+l.get(0)+" "+l.get(1)+" "+l.get(2));
			
			if(!Pattern.matches("#[0-9]+",((String)l.get(2))))
			{
				reg2=Integer.parseInt(((String)l.get(2)).substring(1));
				return MOV_reg;
			}
			else
			{
				immediate=Integer.parseInt(((String)l.get(2)).substring(1));
				return MOV_immediate;
			}
		}
		else if(((String)l.get(0)).equals("ADD") || ((String)l.get(0)).equals("SUB") || ((String)l.get(0)).equals("MULT") || ((String)l.get(0)).equals("DIV") || ((String)l.get(0)).equals("MOD"))
		{
			if(l.size()!=4)
				throw new InvalidInstructionFormatException(instr, instr_no);
			if(!Pattern.matches("R[1-9]",((String)l.get(1))) && !Pattern.matches("R[1-2]\\d?",((String)l.get(1))) && !Pattern.matches("R3[0-2]",((String)l.get(1))))
				throw new InvalidInstructionFormatException(instr, instr_no);
			if(!Pattern.matches("R[1-9]",((String)l.get(2))) && !Pattern.matches("R[1-2]\\d?",((String)l.get(2))) && !Pattern.matches("R3[0-2]",((String)l.get(2))))
				throw new InvalidInstructionFormatException(instr, instr_no);
			if(!Pattern.matches("R[1-9]",((String)l.get(3))) && !Pattern.matches("R[1-2]\\d?",((String)l.get(3))) && !Pattern.matches("R3[0-2]",((String)l.get(3))) && !Pattern.matches("#[0-9]+",((String)l.get(3))))
				throw new InvalidInstructionFormatException(instr, instr_no);
			
			reg1=Integer.parseInt(((String)l.get(1)).substring(1));
			reg2=Integer.parseInt(((String)l.get(2)).substring(1));
			
			//System.out.println(l.size()+" "+l.get(0)+" "+l.get(1)+" "+l.get(2)+" "+l.get(3));
			
			if(!Pattern.matches("#[0-9]+",((String)l.get(3))))
			{
				reg3=Integer.parseInt(((String)l.get(3)).substring(1));
				return ADD_reg;
			}
			else
			{
				immediate=Integer.parseInt(((String)l.get(3)).substring(1));
				return ADD_immediate;
			}
		}
		else if(((String)l.get(0)).equals("BEQ") || ((String)l.get(0)).equals("BNE") || ((String)l.get(0)).equals("BGE") || ((String)l.get(0)).equals("BLE") || ((String)l.get(0)).equals("BGT") || ((String)l.get(0)).equals("BLT"))
		{
			if(l.size()!=4)
				throw new InvalidInstructionFormatException(instr, instr_no);
			if(!Pattern.matches("R[1-9]",((String)l.get(1))) && !Pattern.matches("R[1-2]\\d?",((String)l.get(1))) && !Pattern.matches("R3[0-2]",((String)l.get(1))))
				throw new InvalidInstructionFormatException(instr, instr_no);
			if(!Pattern.matches("R[1-9]",((String)l.get(2))) && !Pattern.matches("R[1-2]\\d?",((String)l.get(2))) && !Pattern.matches("R3[0-2]",((String)l.get(2))) && !Pattern.matches("#[0-9]+",((String)l.get(2))))
				throw new InvalidInstructionFormatException(instr, instr_no);
			if(!Pattern.matches("([a-z]|[A-Z])([a-z]|[A-Z]|[0-9]|_)*",((String)l.get(3))))
				throw new InvalidInstructionFormatException(instr, instr_no);
			
			reg1=Integer.parseInt(((String)l.get(1)).substring(1));
			
			if(labels.get(l.get(3))==null)
				throw new InvalidInstructionFormatException(instr,instr_no);
			label=((Integer)labels.get(l.get(3))).intValue();			
			//System.out.println(l.size()+" "+l.get(0)+" "+l.get(1)+" "+l.get(2)+" "+l.get(3));
			
			if(!Pattern.matches("#[0-9]+",((String)l.get(2))))
			{
				reg2=Integer.parseInt(((String)l.get(2)).substring(1));
				if(((String)l.get(0)).equals("BEQ"))
					return BEQ_reg;
				else if(((String)l.get(0)).equals("BNE"))
					return BNE_reg;
				else if(((String)l.get(0)).equals("BGT"))
					return BGT_reg;
				else if(((String)l.get(0)).equals("BLT"))
					return BLT_reg;
				else if(((String)l.get(0)).equals("BGE"))
					return BGE_reg;
				else
					return BLE_reg;
			}
			else
			{
				immediate=Integer.parseInt(((String)l.get(2)).substring(1));
				if(((String)l.get(0)).equals("BEQ"))
					return BEQ_immediate;
				else if(((String)l.get(0)).equals("BNE"))
					return BNE_immediate;
				else if(((String)l.get(0)).equals("BGT"))
					return BGT_immediate;
				else if(((String)l.get(0)).equals("BLT"))
					return BLT_immediate;
				else if(((String)l.get(0)).equals("BGE"))
					return BGE_immediate;
				else
					return BLE_immediate;
			}
		}
		else if(((String)l.get(0)).equals("END"))
			return END;
		else
			return INVALID;
	}
	
	public ArrayList pruneEmptyWords(ArrayList l)
	{
		for(int i=0;i<l.size();i++)
		{
			if(((String)l.get(i)).equals(""))
				l.remove(i);
		}
		return l;
	}
	
	public boolean notInstruction(String str)
	{
		if(str.equals("END") || str.equals("MOV") || str.equals("ADD") || str.equals("SUB") || str.equals("BEQ") || str.equals("BNE") || str.equals("BLT") || str.equals("BGT") || str.equals("BLE") || str.equals("BGE") || str.equals("MOD") || str.equals("DIV") || str.equals("MULT"))
		{
			return false;
		}
		else
			return true;
	}
	
	public void showInstructions()
	{
		for(int i=0;i<instructions.size();i++)
		{
			System.out.println(instructions.get(i));
		}
	}
	
	public void showRegisters()
	{
		for(int i=0;i<32;i++)
		{
			System.out.println("R"+(i+1) + " " + registers.get(i));
		}
	}
}
